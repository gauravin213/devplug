jQuery(document).ready(function ($) {

    function updateAnyProduct(checkbox) {
        if (!checkbox.is(':checked')) {
            $('.not-any-product').show();
        } else {
            $('.not-any-product').hide();
        }
    }

    $(document).on('change','.any-product',function () {
        updateAnyProduct($(this));
    });
    updateAnyProduct($('.any-product'));


    $(document).on('change','.product-option-group-categories',function () {
        if ($(this).find(':selected').length > 0) {
            $('.product-option-group-query').hide();
        } else {
            $('.product-option-group-query').show();
        }
    });
	
	$('.product-option-group-attributes').closest('form').submit(function() {
		$('#new-product-option-group-attribute').remove();
	});
	
	$(document).on('click','.remove-new-product-option-group-attribute',function() {
		var attributeToRemove = $(this).closest('.product-option-group-attribute');
		attributeToRemove.hide(500);
		setTimeout(function() {attributeToRemove.remove();},500);
	});
	
	$('.add-new-product-option-group-attribute').click(function() {
		var newAttribute = $('#new-product-option-group-attribute').html();
		var maxId = 0;
		$('.product-option-group-attributes').find('.product-option-group-attribute-id').each(function () {
			if (parseInt($(this).val()) > parseInt(maxId))
				maxId = $(this).val();
		});
		maxId = parseInt(maxId) + 1;
		newAttribute = newAttribute.replace(new RegExp('new_attribute_id', "g"), maxId);
		$('.product-option-group-attributes').append(newAttribute);
		$('.product-option-group-attributes').find('.product-option-group-attribute-' + maxId).hide(0);
		$('.product-option-group-attributes').find('.product-option-group-attribute-' + maxId).show(500);
		setTimeout(function() {
			$('.product-option-group-attributes').find('.product-option-group-attribute-' + maxId).find(
				'.product-option-group-attribute-taxonomy, .product-option-group-attribute-taxonomy-attributes').each(function() {
				$(this).select2();
			});
			$('.product-option-group-attributes').find('.product-option-group-attribute-' + maxId).find('.product-option-group-attribute-taxonomy').change();
		}, 500);
	});

	$('.product-option-group-attributes .product-option-group-attribute-taxonomy, .product-option-group-attributes .product-option-group-attribute-taxonomy-attributes').each(function() {
		$(this).select2();
	});
	
	$('.product-option-group-attributes-wrapper').on('change', '.product-option-group-attribute-taxonomy', function() {
		if($(this).val() == 'custom-product-attribute') {
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-taxonomy-attributes-wrapper').hide(500);
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-custom-attribute').show(500);
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-taxonomy-attributes').html('');
		} else if($(this).val() == '') {
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-taxonomy-attributes-wrapper').hide(500);
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-custom-attribute').hide(500);
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-taxonomy-attributes').html('');
		} else {
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-taxonomy-attributes-wrapper').show(500);
			$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-custom-attribute').hide(500);
			if( !init && typeof woocommerce_product_option_group_settings['attribute_taxonomy_data'][$(this).val()] != 'undefined' ) {
				var attributes = woocommerce_product_option_group_settings['attribute_taxonomy_data'][$(this).val()];
				var attributeId = $(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-id').val();
				var options = '';
				$.each( attributes, function( index, value ) {
					options += '<option value="' + index + '">' + value + '</option>';
				});
				$(this).closest('.product-option-group-attribute').find('.product-option-group-attribute-taxonomy-attributes').html(options);
			}
			
		}
	});
	var init = true;
	$('.product-option-group-attributes .product-option-group-attribute-taxonomy').change();
	init = false;
});