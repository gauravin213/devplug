<?php

if ( !defined( 'ABSPATH' ) )
    exit;

/**
 * This class creates VC shortcodes from the arrays of arrays in woocommerce-shortcodes.php
 */
class Woocommerce_Product_Options_Gutenberg_Factory {

    static $properties_of_shortcodes = array();
    static $initialized = false;
    static $vc_properties = array();
    static $js = '';
    static $scripts_enqueued = false;
    static $shortcodes = array();

    static function convert_to_attributes( $shortcode, $properties ) {
        return array( 'shortcode' => array( 'type' => 'string', 'source' => 'children',
                'selector' => '.wpofg-product-options-shortcode' ), );
    }

    static function register_block( $shortcode, $properties, $post_id ) {
        self::$shortcodes[ str_replace( '_', '-', $shortcode ) ] = $properties;
        $shortcode_func = function( $atts, $content ) use( $shortcode, $post_id ) { 
			return Woocommerce_Product_Options_Gutenberg_Factory::do_woocommerce_shortcode( $shortcode, $atts, $content, $post_id ); };
		register_block_type( 'wpofg-product/' . str_replace( '_', '-', $shortcode ), array(
            'render_callback' => $shortcode_func,
            'editor_script' => 'woocommerce-product-for-gutenberg-editor',
            'editor_style' => 'woocommerce-product-for-gutenberg-editor',
        ) );
    }

    /**
     * Gets all the shortcodes from woocommerce-shortcodes.php and adds them to VC.
     */
    static function init() {
        if ( self::$initialized ) {
            return;
        }
        if ( !isset( $_SESSION ) ) {
            @session_start();
        }
        $post_id = value( $_REQUEST, 'post' );
        global $post;
        if ( empty( $post ) ) {
            $post = get_post( $post_id );
            $action = value( $_REQUEST, 'action' );
        } else {
            $post_id = $post->ID;
        }
        if ( empty( $post_id ) ) {
            $last_revision_time = value( $_SESSION, '_wpofg_edit_post_id_modified', 0 );
            $post_id = value( $_SESSION, '_wpofg_edit_post_id', 0 );
            $last_revision_time = 0;
            global $wpdb;
            $sql = "SELECT UNIX_TIMESTAMP(MAX(pc.post_modified_gmt)) AS gmt_time_unix, MAX(pc.post_modified_gmt) AS gmt_time FROM {$wpdb->prefix}posts pc INNER JOIN {$wpdb->prefix}posts pp ON pc.post_parent=pp.ID
            WHERE pp.post_type='product' AND pc.post_type='revision';";
            $last_revision_row = $wpdb->get_row( $sql );
            if ( !empty( $last_revision_row ) ) {
                if ( $last_revision_row->gmt_time_unix > $last_revision_time ) {
                    $sql = $wpdb->prepare( "SELECT pp.ID FROM {$wpdb->prefix}posts pc INNER JOIN {$wpdb->prefix}posts pp 
                ON pc.post_parent=pp.ID AND pc.post_type='revision' AND pp.post_type='product' AND 
                pc.post_modified_gmt=%s", $last_revision_row->gmt_time );
                    $post_id = $wpdb->get_var( $sql );
                }
            }
            if ( !empty( $post_id ) ) {
                $post = get_post( $post_id );
            }
        }
        if ( !empty( $post ) ) {
            if ( $post->post_type != 'product' ) {
                return;
            }
        } else {
            return;
        }
        wp_register_script(
                'woocommerce-product-for-gutenberg-editor', plugins_url( '../assets/js/product-editor.js', __FILE__ ), array(
            'wp-blocks', 'wp-element' )
        );
        wp_register_style(
                'woocommerce-product-for-gutenberg-editor', plugins_url( '../assets/css/product-editor.css', __FILE__ )
        );
        self::$initialized = true;
        global $woocommerce_product_options_gutenberg_product_attributes;
        foreach ( $woocommerce_product_options_gutenberg_product_attributes as $shortcode =>
                    $woocommerce_product_attribute ) {
            self::register_block( $shortcode, $woocommerce_product_attribute, $post_id );
        }
        wp_localize_script( 'woocommerce-product-for-gutenberg-editor', 'woocommerce_product_for_gutenberg_editor_settings', array(
            'product_shortcodes' => self::$shortcodes ) );
        add_action( 'add_meta_boxes_product', 'Woocommerce_Product_Options_Gutenberg_Factory::add_meta_boxes_product' );
        //wp_enqueue_style( 'font-awesome', plugins_url( '../css/fa/css/all.min.css', __FILE__ ) );
        add_filter( 'wc_get_template_part', 'Woocommerce_Product_Options_Gutenberg_Factory::wc_get_template_part', 10, 3 );
    }

    static function add_meta_boxes_product( $post ) {
        $_SESSION[ '_wpofg_edit_post_id' ] = $post->ID;
        $_SESSION[ '_wpofg_edit_post_id_modified' ] = time();
    }

    static function add_subelement_css( $properties_of_shortcode, $atts, $uid ) {
        $json = urldecode( value( $atts, 'subelement_css' ) );
        $has_subelement_css = false;
        if ( !empty( $json ) && !empty( $properties_of_shortcode[ 'elements' ] ) ) {
            $subelement_css = ( array ) json_decode( $json );
            $elements = $properties_of_shortcode[ 'elements' ];
            if ( !empty( $subelement_css ) ) {
                $js = '';
                foreach ( $subelement_css as $element ) {
                    $element = ( array ) $element;
                    $element_id = value( $element, 'choose_element' );
                    $element_property = value( value( $elements, $element_id, array() ), 'css_selector' );
                    if ( $element_property == '' ) {
                        continue;
                    }
                    $js .= '$(\'#' . $uid . ' ' . str_replace( ',', ',#' . $uid, $element_property ) . '\')';
                    foreach ( $element as $element_param_id => $element_param ) {
                        if ( $element_param_id == 'choose_element' ) {
                            continue;
                        }
                        $js .= '.css(\'' . str_replace( '_', '-', $element_param_id ) . '\', \'' . $element_param . '\')';
                    }
                    $js.=';';
                    $has_subelement_css = true;
                }
                self::$js .=$js;
            }
        }
        return $has_subelement_css;
    }

    /**
     * Apart from the cart and checkout shortcodes (which are printed by classes in vc-vendor.php), this
     * function prints the shortcodes in the frontend .
     */
    static function do_woocommerce_shortcode( $shortcode, $atts, $content, $post_id ) {
        global $woocommerce_product_options_gutenberg_product_attributes;
        global $product;
        global $post;
        $properties_of_shortcode = value( $woocommerce_product_options_gutenberg_product_attributes, $shortcode, NULL );
        if ( !is_single() ) {
            if ( in_array( $shortcode, array( 'woocommerce_template_single_meta',
                        'woocommerce_show_product_sale_flash',
                        'woocommerce_upsell_display', 'woocommerce_template_single_rating',
                        'comments_template', 'woocommerce_template_single_price', 'product_options',
                    ) ) ) {
                $html = '<div class="wpofg-shortcode-box">' . $properties_of_shortcode[ 'label' ] . '</div>';
                return '<div>' . $html . '</div>';
            }
        }
        if ( !empty( $post_id ) ) {
            if ( empty( $product ) ) {
                $product = wc_get_product( $post_id );
            }
            if ( empty( $post ) ) {
                $post = get_post( $post_id );
            }
        }
        $uid = md5( rand( 0, 100000 ) . microtime() );
        $atts = apply_filters( 'vc_woocommerce_add_on_' . $shortcode . '_attributes', $atts );
        $css = '';
        extract( shortcode_atts( array(
            'css' => '' ), $atts ) );
        $css_class = 'test';
        $has_subelement_css = self::add_subelement_css( $properties_of_shortcode, $atts, $uid );
        if ( $properties_of_shortcode === NULL ) {
            return sprintf( __( 'Error - shortcode %s not found', 'vc-woocommerce-add-on' ), $shortcode );
        }
        $style = value( $atts, 'style' );
        if ( !empty( $css_class ) ) {
            $css_class = 'wc-woocommerce-add-on-css-classes ' . esc_attr( $css_class );
        }
        $css_class .= ' vc-woocommerce-element-wrapper ' . sanitize_title( $shortcode );
        ob_start();
        if ( !empty( $css_class ) || !empty( $style ) || $has_subelement_css ) {
            print '<div class="' . $css_class . '" style="' . $style . '" id="' . $uid . '" >';
        }
        if ( !empty( $properties_of_shortcode[ 'action_before' ] ) ) {
            do_action( $properties_of_shortcode[ 'action_before' ], $atts, $content );
        }
        print do_shortcode( value( $properties_of_shortcode, 'html_before' ) );
        $has_child = false;
        if ( !empty( $properties_of_shortcode[ 'items' ] ) ) {
            foreach ( $properties_of_shortcode[ 'items' ] as $child_shortcode =>
                        $child_shortcode_properties ) {
                if ( has_shortcode( $content, $child_shortcode ) ) {
                    $has_child = true;
                }
            }
        }
        if ( $has_child ) {
            
        } elseif ( function_exists( $shortcode ) ) {
            $shortcode();
        } elseif ( $shortcode == 'woocommerce_product_additional_information' ) {
            wc_display_product_attributes( $product );
        } else {
            do_action( $shortcode, $atts, $content, $shortcode );
        }
        print do_shortcode( $content );
        if ( !empty( $properties_of_shortcode[ 'action' ] ) ) {
            do_action( $properties_of_shortcode[ 'action' ], $atts, $content );
        }
        print do_shortcode( value( $properties_of_shortcode, 'html_after' ) );
        if ( !empty( $properties_of_shortcode[ 'action_after' ] ) ) {
            do_action( $properties_of_shortcode[ 'action_after' ], $atts, $content );
        }
        if ( !empty( $css_class ) || !empty( $style ) || $has_subelement_css ) {
            print '</div>';
        }
        $html = trim( ob_get_clean() );
        return '<div>' . $html . '</div>';
    }

    static function wc_get_template_part( $template, $slug, $name ) {
        if ( $slug == 'content' && $name == 'single-product' ) {
            return dirname( __FILE__ ) . '/content-single-product.php';
        }
        return $template;
    }

}

add_action( 'init', 'Woocommerce_Product_Options_Gutenberg_Factory::init', 20 );
