<?php

$woocommerce_product_options_gutenberg_product_attributes = array(
            'woocommerce_show_product_sale_flash' => array(
                'label' => __( 'Product Sales Flash', 'vc-woocommerce-add-on' ),
                'icon' => 'money',
                /*'attributes' => array( //attributes are not used at the moment
                    'crossed_out_text' => array(
                        'css_selector' => '.price del',
                        'label' => __( 'Crossed Out Text',
                                'vc-woocommerce-add-on' ),
                    ),
                    'uncrossed_out_text' => array(
                        'css_selector' => '.price ins',
                        'label' => __( 'Uncrossed Out Text',
                                'vc-woocommerce-add-on' ),
                    ),
                ),*/
            ),
            /*'woocommerce_show_product_images' => array( 'label' => __( 'Product Gallery',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'images',
                'attributes' => array(
                    'product_image' => array(
                        'css_selector' => '.images .attachment-shop_single, .images .wp-post-image',
                        'label' => __( 'Main Product Image',
                                'vc-woocommerce-add-on' ),
                    ),
                    'thumbnail' => array(
                        'css_selector' => '.images .thumbnails img',
                        'label' => __( 'Thumbnail', 'vc-woocommerce-add-on' ),
                    ),
                ), ),*/
            'woocommerce_template_single_price' => array( 'label' => __( 'Product Price',
                        'vc-woocommerce-add-on' ), 'icon'=>'dollar-sign', ),
            /*'woocommerce_template_single_excerpt' => array( 'label' => __( 'Excerpt (Deprecated)',
                        'vc-woocommerce-add-on' ), ),*/
            'woocommerce_template_single_add_to_cart' => array( 'label' => __( 'Add To Cart (including variations)',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'cart-plus',
                'attributes' => array(
                    'quantity' => array(
                        'css_selector' => 'input.qty',
                        'label' => __( 'Quantity', 'vc-woocommerce-add-on' ),
                    ),
                    'add_to_cart_button' => array(
                        'css_selector' => '.images .thumbnails img',
                        'label' => __( 'Add To Cart Button',
                                'vc-woocommerce-add-on' ),
                    ),
                ), ),
            'woocommerce_template_single_meta' => array( 'label' => __( 'Product Meta',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'info',
                'attributes' => array(
                    'sku' => array(
                        'css_selector' => '.sku',
                        'label' => __( 'SKU', 'vc-woocommerce-add-on' ),
                    ),
                    'meta_tag' => array(
                        'css_selector' => 'a[rel="tag"]',
                        'label' => __( 'Tag/Category',
                                'vc-woocommerce-add-on' ),
                    ),
                ), ),
            'woocommerce_product_additional_information' => array( 'label' => __( 'Additional Product Information',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'info-circle',
                         'action' => 'woocommerce_product_additional_information_tab',
                'attributes' => array(
                    'additional_information_heading' => array(
                        'css_selector' => 'h2',
                        'label' => __( 'Additional Information Heading',
                                'vc-woocommerce-add-on' ),
                    ),
                    'attribute_field' => array(
                        'css_selector' => '.shop_attributes th',
                        'label' => __( 'Attribute Field',
                                'vc-woocommerce-add-on' ),
                    ),
                    'attribute_value_field' => array(
                        'css_selector' => '.shop_attribute td',
                        'label' => __( 'Shop Attribute Value',
                                'vc-woocommerce-add-on' ),
                    ),
                ), ),
            'woocommerce_upsell_display' => array( 'label' => __( 'Upsell Products',
                        'vc-woocommerce-add-on' ), 'description' => __( 'You may also like ...',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'sellsy',
                'attributes' => array(
                    'upsell_heading' => array(
                        'css_selector' => '.upsells h2',
                        'label' => __( 'Heading (You may also like...)',
                                'vc-woocommerce-add-on' ),
                    ),
                    'upsell_image' => array(
                        'css_selector' => '.upsells .wp-post-image',
                        'label' => __( 'Upsell Product Image',
                                'vc-woocommerce-add-on' ),
                    ),
                    'upsell_product_title' => array(
                        'css_selector' => '.upsells h3',
                        'label' => __( 'Upsell Product Title',
                                'vc-woocommerce-add-on' ),
                    ),
                    'upsell_price' => array(
                        'css_selector' => '.upsells .price',
                        'label' => __( 'Upsell Product Price',
                                'vc-woocommerce-add-on' ),
                    ),
                    'upsell_add_to_cart_button' => array(
                        'css_selector' => '.upsells .add_to_cart_button',
                        'label' => __( 'Upsell Add To Cart Button',
                                'vc-woocommerce-add-on' ),
                    ),
                ), ),
            'comments_template' => array( 'label' => __( 'Product Reviews',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'smile-o',
                'attributes' => array(
                    'reviews_title' => array(
                        'css_selector' => '.woocommerce-Reviews-title',
                        'label' => __( 'Title (e.g. 10 reviews for T-Shirt)',
                                'vc-woocommerce-add-on' ),
                    ),
                    'product_title_in_reviews_title' => array(
                        'css_selector' => '.woocommerce-Reviews-title span',
                        'label' => __( 'Product title within reviews title (e.g. T-Shirt)',
                                'vc-woocommerce-add-on' ),
                    ),
                    'review' => array(
                        'css_selector' => '.review',
                        'label' => __( 'Entire Review',
                                'vc-woocommerce-add-on' ),
                    ),
                    'review_avatar' => array(
                        'css_selector' => '.review img.avatar',
                        'label' => __( 'Review Gravatar',
                                'vc-woocommerce-add-on' ),
                    ),
                    'review_date' => array(
                        'css_selector' => '.review time',
                        'label' => __( 'Review Date',
                                'vc-woocommerce-add-on' ),
                    ),
                    'review_paragraph' => array(
                        'css_selector' => '.review .description p',
                        'label' => __( 'Paragraph in review text',
                                'vc-woocommerce-add-on' ),
                    ),
                ), ),
            'woocommerce_template_single_rating' => array( 'label' => __( 'Product Rating',
                        'vc-woocommerce-add-on' ),
                        'icon'=>'star-o',
                'attributes' => array(
                    'reviews_link' => array(
                        'css_selector' => '#reviews',
                        'label' => __( 'Text (e.g. 10 customer reviews)',
                                'vc-woocommerce-add-on' ),
                    ),
                    'add_to_cart_button' => array(
                        'css_selector' => '#reviews .count',
                        'label' => __( 'Reviews count (e.g. 10)',
                                'vc-woocommerce-add-on' ),
                    ),
                ), ),
            'product_options' => array('label'=>__('Product Options','vc-woocommerce-add-on'),'icon'=>''),
);


/**
 * Function displays additional information about product attributes on the product page
 */
if ( !function_exists( 'woocommerce_product_additional_information' ) ) {

    function woocommerce_product_additional_information() {
        global $product;
        $heading = apply_filters( 'woocommerce_product_additional_information_heading',
                __( 'Additional Information', 'vc-woocommerce-add-on' ) );
        ?>
        <?php if ( $heading ): ?>
            <h2><?php echo $heading; ?></h2>
        <?php endif; ?>
        <?php wc_display_product_attributes( $product ); ?>
        <?php
    }

}

if ( !function_exists( 'number_of_reviews' ) ) {

    function number_of_reviews() {
        global $product;
        if ( empty( $product ) ) {
            global $post;
            if ( !empty( $post ) && $post->post_type == 'product' ) {
                $product = wc_get_product( $post->ID );
            } else {
                return '';
            }
        }
        return $product->get_review_count();
    }

}

if ( !function_exists( 'product_options' ) ) {

    function product_options() {
        return do_shortcode( '[product_options]' );
    }

}

function woocommerce_product_options_gutenberg_product_shortcodes() {
    add_shortcode( 'number_of_reviews', 'number_of_reviews' );
    add_shortcode( 'wc_get_cart_url', 'wc_get_cart_url' );
}

add_action( 'init', 'woocommerce_product_options_gutenberg_product_shortcodes' );