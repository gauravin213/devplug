<?php
if ( !defined( 'ABSPATH' ) )
    exit;
/**
 * This file overrides WooCommerce product template
 */
Woocommerce_Product_Options_Gutenberg_Factory::init();
$the_content = get_the_content();
$content_written = false;
global $product;
$product = wc_get_product( get_the_id() );
global $woocommerce_product_options_gutenberg_product_attributes;
foreach ( $woocommerce_product_options_gutenberg_product_attributes as $shortcode => $properties ) {
    if ( strpos( $the_content, '<!-- wp:wpofg-product/' . str_replace( '_', '-', $shortcode ) . ' ' ) ) {
        ?>
        <div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
            <?php
            ob_start();
            the_content();
            $html = ob_get_clean();
            print do_shortcode( str_replace( '`{`number_of_reviews`}`', number_of_reviews(), $html ) );
            $content_written = true;
            ?>
        </div>
            <?php
            break;
        }
    }
    if ( !$content_written ) {
        remove_filter( 'wc_get_template_part', 'Woocommerce_Product_Options_Gutenberg_Factory::wc_get_template_part', 10, 3 );
        wc_get_template_part( 'content', 'single-product' );
    }