<?php

class WooCommerce_Product_Options_Gutenberg {

    function __construct() {
        add_action( 'gutenberg_can_edit_post_type', array( $this, 'gutenberg_can_edit_post_type' ), 10, 2 );
    }

    function gutenberg_can_edit_post_type( $can_edit, $post_type ) {
        if ( $post_type == 'product' ) {
            return true;
        }
        return $can_edit;
    }

};

$woocommerce_product_options_gutenberg = new WooCommerce_Product_Options_Gutenberg();
