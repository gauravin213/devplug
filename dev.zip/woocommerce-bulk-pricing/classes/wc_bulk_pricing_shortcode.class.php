<?php

class woocommerce_bulk_pricing_shortcode {

    static function showHtmlTable( $rules, $post_id = false, $max_columns = false ) {
        global $woocommerce;
        global $woocommerce_bulk_pricing;

        if ( ! is_array($rules) ) return;

        $original_price = false;
        if ( $post_id ) {
            $_product = self::wc2_get_product( $post_id );
            $original_price = $_product->get_price();
            $combine_wholesale = false;

            // wholesale mod
            if ( $global_percent = $woocommerce_bulk_pricing->getUserDiscount() ) {

                if ( $woocommerce_bulk_pricing->userDiscountIsCombinedWithBulkPricing() ) {
                    
                    // apply global percentage discount to original_price
                    $original_price = $original_price - ( $original_price * $global_percent / 100 );
                    $combine_wholesale = true;

                } else {
                    // apply global percentage discount only
                    // $price_adjusted = $original_price - ( $original_price * $global_percent / 100 );
                }
            }

        }
        echo '<table>';

        // table header
        echo '<tr class="wc_quantity">';
        $col_index = 0;
        foreach ( $rules as $rule ) {
            $title = $rule['min'] . '-' . $rule['max'];
            if ( $rule['max'] == '*' ) $title = $rule['min'] . '+';
            if ( $rule['min'] == $rule['max'] ) $title = $rule['min'];
            $title = apply_filters( 'woocommerce_bulk_pricing_table_title', $title, $original_price, $rule, $rules, $post_id, $col_index );
            echo '<th>'.$title.'</th>';
            $col_index++;

            if ( $max_columns && ( $col_index > $max_columns ) ) break;
        }
        echo '</tr>';

        // table body
        echo '<tr class="wc_price">';
        $col_index = 0;
        foreach ( $rules as $rule ) {
			$title = $rule['min'] . '-' . $rule['max'];
            if ( $rule['max'] == '*' ) $title = $rule['min'] . '+';
            if ( $rule['min'] == $rule['max'] ) $title = $rule['min'];
            $title = apply_filters( 'woocommerce_bulk_pricing_table_title', $title, $original_price, $rule, $rules, $post_id, $col_index );
			
            $value = $rule['val'];
			$discount_price = 0;
            // calc prices if product id provided
            if ( $post_id ) {
                if ( $value == '100%' ) {
                    // 100% equals original price
                    $value = $woocommerce_bulk_pricing->format_price( $original_price );
					$discount_price = $original_price;
                } elseif ( strpos( $value, '%' ) > 0 ) {
                    // no currency for percentages
                    $value = $value;

                    // calculate relative prices as well
                    $percentage = floatval( str_replace( '%', '', $value ) / 100 );
                    $value = $woocommerce_bulk_pricing->format_price( $original_price * $percentage );
					$discount_price = $original_price * $percentage;

                } elseif ( '+' == substr( $value, 0, 1 ) ) {
                    // increase price by adding value
                    $value = $original_price + $value;
                    $value = $woocommerce_bulk_pricing->format_price( $value );
					$discount_price = $original_price;
                } elseif ( '-' == substr( $value, 0, 1 ) ) {
                    // reduce price by adding negative value
                    $value = $original_price + $value;
					$discount_price = $value;
                    $value = $woocommerce_bulk_pricing->format_price( $value );
                } else {
                    // default - add currency symbol
                    if ( $combine_wholesale ) $value = $value - ( $value * $global_percent / 100 );
					$discount_price = $value;
                    $value = $woocommerce_bulk_pricing->format_price( $value );
                }
            }

            $value = apply_filters( 'woocommerce_bulk_pricing_table_value', $value, $original_price, $rule, $rules, $post_id, $col_index );
            echo '<td align="center" data-quantity="'.$title.'" data-price="'.$discount_price.'">'.$value.'</td>';
            $col_index++;

            if ( $max_columns && ( $col_index > $max_columns ) ) break;
        }
        echo '</tr>';

        echo '</table>';
        do_action( 'woocommerce_bulk_pricing_table_footer', $rule, $rules, $post_id );

    }

    static function showInlineJS( $ruleset_id, $post_id ) {
        ?>
            <script type="text/javascript">

                jQuery(document).on( 'change', '.variations select', function() {

                    variation_form = jQuery('form.variations_form');
                    var variation_id = variation_form.find('input[name=variation_id]').val();

                    if ( ! ajaxurl ) var ajaxurl = "<?php echo admin_url('admin-ajax.php') ?>";

                    if ( variation_id ) {

                        jQuery('#wpl_bp_wrap').load( ajaxurl, { 
                            'action': 'wpl_bp_load_discount_table', 
                            'post_id': "<?php echo $post_id ?>",
                            'ruleset_id': "<?php echo $ruleset_id ?>",
                            'variation_id': variation_id 
                        });

                        jQuery('#wpl_bp_wrap span.amount').css('color','transparent');
                        jQuery('#wpl_bp_wrap span.amount').css('color','rgba(0,0,0,.3)');
                        // jQuery('#wpl_bp_wrap span.amount').animate({'color':'#ffffff'},200);

                    }

                });

            </script>
        <?php

                // jQuery(document).bind('woocommerce_update_variation_values', function() {
                //     jQuery('.variations select option').each( function(index, el) {
                //     });
                // });
    }


    /**
     * Gets the identified product. Compatible with WC 2.0 and backwards
     * compatible with previous versions
     *
     * @param int     $product_id the product identifier
     * @param array   $args       optional array of arguments
     *
     * @return WC_Product the product
     */
    static function wc2_get_product( $product_id, $args = array() ) {
        $product = null;

        if ( version_compare( WOOCOMMERCE_VERSION, "2.0.0" ) >= 0 ) {
            // WC 2.0
            $product = get_product( $product_id, $args );
        } else {

            // old style, get the product or product variation object
            if ( isset( $args['parent_id'] ) && $args['parent_id'] ) {
                $product = new WC_Product_Variation( $product_id, $args['parent_id'] );
            } else {
                // get the regular product, but if it has a parent, return the product variation object
                $product = new WC_Product( $product_id );
                if ( $product->get_parent() ) {
                    $product = new WC_Product_Variation( $product->id, $product->get_parent() );
                }
            }
        }

        return $product;
    }

}

// 
// template tag
// wc_bulk_pricing_discount_table()
// 
function wc_bulk_pricing_discount_table() {
    global $woocommerce_bulk_pricing;
    $woocommerce_bulk_pricing->display_discount_info();
}
