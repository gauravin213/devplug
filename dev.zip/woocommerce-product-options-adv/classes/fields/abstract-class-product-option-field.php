<?php
/**
 * Product_Option_Field
 */
abstract class Product_Option_Field {
	public $option;
	public $value;

	/**
	 * Constructor
	 */
	public function __construct( $option, $value = '' ) {
		$this->option = $option;
		$this->value = $value;
	}

	/**
	 * Get data for the posted option
	 */
	public function get_cart_item_data() {
		return false;
	}

	/**
	 * Validate an option
	 * @return bool pass or fail, or WP_Error
	 */
	public function validate() {
		return true;
	}

	/**
	 * Get the name of the posted option
	 * @return string
	 */
	public function get_field_name() {
		return 'option-' . sanitize_title( $this->option['field-name'] );
	}

	/**
	 * Get the label for an option
	 * @param  string $option The option array object
	 * @return string
	 */
	public function get_option_label( $option ) {
		return ! empty( $option['label'] ) ? sanitize_text_field( $this->option['name'] ) . ' - ' . sanitize_text_field( $option['label'] ) : sanitize_text_field( $this->option['name'] );
	}

	/**
	 * Get the price for an option
	 * @param  string $option The option array object
	 * @return string
	 */
	public function get_option_price( $option ) {
		return $option['price'];
	}	
}