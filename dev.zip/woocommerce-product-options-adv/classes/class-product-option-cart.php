<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product_Option_cart class.
 */
class Product_Option_Cart {

	/**
	 * Constructor
	 */
	function __construct() {
		// Add to cart
		add_filter( 'woocommerce_add_cart_item', array( $this, 'add_cart_item' ), 100000, 1 );

		// Load cart data per page load
		add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'get_cart_item_from_session' ), 100000, 2 );

		// Get item data to display
		add_filter( 'woocommerce_get_item_data', array( $this, 'get_item_data' ), 10, 2 );

		// Add item data to the cart
		add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_cart_item_data' ), 10, 2 );

		// Validate when adding to cart
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_cart_item' ), 999, 3 );

		// Add meta to order
		add_action( 'woocommerce_add_order_item_meta', array( $this, 'order_item_meta' ), 10, 2 );

		// order again functionality
		add_filter( 'woocommerce_order_again_cart_item_data', array( $this, 're_add_cart_item_data' ), 10, 3 );
		
		add_action( 'woocommerce_cart_calculate_fees', array( $this, 'rf_add_cart_surcharge') );
		
		//add_action( 'woocommerce_before_calculate_totals', array( $this, 'rf_add_custom_price') );
		
		//add_filter( 'woocommerce_cart_item_name', array( $this, 'isa_woo_cart_attribute_values'), 10, 2 );
		
		//add_filter('woocommerce_hidden_order_itemmeta', array( $this, 'custom_woocommerce_hidden_order_itemmeta'), 10, 1);
	}

	public function rf_add_custom_price( $cart_object ) {
		$custom_price = 10; // This will be your custome price  
		//echo '<pre>';print_r($cart_object);echo '</pre>';exit;
		foreach ( $cart_object->cart_contents as $key => $value ) {
			$value['_custom_price'] = $value['data']->price;
			//$value['data']->adjust_price($custom_price);
		}
	}
    /**
     * Add an error
     */
    public function add_error( $error ) {
		wc_add_notice( $error, 'error' );
	}

	/**
	 * add_cart_item function.
	 *
	 * @access public
	 * @param mixed $cart_item
	 * @return void
	 */
	public function add_cart_item( $cart_item ) {
		// Adjust price if options are set
		$extra_cost = 0;
		if ( ! empty( $cart_item['options'] ) && apply_filters( 'woocommerce_product_options_adjust_price', true, $cart_item ) ) {

			$extra_cost_once = 0;
			//echo '<pre>';print_r($cart_item);echo '<pre>';exit;
			foreach ( $cart_item['options'] as $option ) {
				if ( $option['price'] > 0 ) {
					$extra_cost += $option['price'];
				}
			}

			//$cart_item['data']->adjust_price( $extra_cost );
		}
		
		/*if ( ! empty( $cart_item['addons'] ) && apply_filters( 'woocommerce_product_addons_adjust_price', true, $cart_item ) ) {

			//$extra_cost = 0;

			foreach ( $cart_item['addons'] as $addon ) {
				if ( $addon['price'] > 0 ) {
					$extra_cost += $addon['price'];
				}
			}

			//$cart_item['data']->adjust_price( $extra_cost );
		}*/
		
		if($extra_cost > 0){
			$cart_item['data']->adjust_price( $extra_cost );
			//$cart_item['data']->set_price($cart_item['_custom_price']+$extra_cost);
		}
		//echo '<pre>';print_r($cart_item['data']->price);echo '<pre>';exit;
		return $cart_item;
	}

	/**
	 * get_cart_item_from_session function.
	 *
	 * @access public
	 * @param mixed $cart_item
	 * @param mixed $values
	 * @return void
	 */
	public function get_cart_item_from_session( $cart_item, $values ) {
		if ( ! empty( $values['options'] ) ) {
			$cart_item['options'] = $values['options'];
			$cart_item = $this->add_cart_item( $cart_item );
		}
		//$cart_item['_custom_price'] = 399;
		//echo '<pre>';print_r($cart_item);exit;
		return $cart_item;
	}

	/**
	 * get_item_data function.
	 *
	 * @access public
	 * @param mixed $other_data
	 * @param mixed $cart_item
	 * @return void
	 */
	public function get_item_data( $other_data, $cart_item ) {
		$item_id = ( !empty( $cart_item['variation_id'] ) ) ? $cart_item['variation_id'] : '';
		if ( !empty( $item_id ) ) {
			$_product = new WC_Product_Variation( $item_id );
    		$variation_data = $_product->get_variation_attributes();
    		$variation_detail = woocommerce_get_formatted_variation( $variation_data, true );
			$cartVariations = explode(':',$variation_detail);
			$variant_price = wc_price($_product->regular_price);
			
			if(count($cartVariations) && count($other_data)){
				foreach($other_data as $key=>$old_data){
					if(strtolower(trim($old_data['key']))==strtolower(trim($cartVariations[0])) && strtolower(trim($old_data['value']))==strtolower(trim($cartVariations[1]))){
						$other_data[$key]['key'] = $other_data[$key]['key'].' ('.$variant_price.')';
					}
				}
			}
		}
		
		if ( ! empty( $cart_item['options'] ) ) {
			foreach ( $cart_item['options'] as $option ) {
				$name = $option['name'];

				if ( $option['price'] > 0 && apply_filters( 'woocommerce_options_add_price_to_name', '__return_true' ) ) {
					$name .= ' (' . wc_price( get_product_option_price_for_display ( $option['price'], $cart_item[ 'data' ], true ) ) . ')';
				}

				$other_data[] = array(
					'name'    => $name,
					'value'   => $option['value'],
					'display' => isset( $option['display'] ) ? $option['display'] : ''
				);
			}
		}
		return $other_data;
	}

	/**
	 * add_cart_item_data function.
	 *
	 * @param array $cart_item_meta
	 * @param int $product_id
	 * @param  bool $test If this is a test i.e. just getting data but not adding to cart. Used to prevent uploads.
	 * @return array of cart item data
	 */
	public function add_cart_item_data( $cart_item_meta, $product_id, $post_data = null, $test = false ) {
		if ( is_null( $post_data ) && isset( $_POST ) ) {
			$post_data = $_POST;
		}

		$product_options = get_product_options( $product_id );

		if ( empty( $cart_item_meta['options'] ) ) {
			$cart_item_meta['options'] = array();
		}

		if ( is_array( $product_options ) && ! empty( $product_options ) ) {
			include_once( 'fields/abstract-class-product-option-field.php' );

			foreach ( $product_options as $option ) {

				$value = isset( $post_data[ 'option-' . $option['field-name'] ] ) ? $post_data[ 'option-' . $option['field-name'] ] : '';

				if ( is_array( $value ) ) {
					$value = array_map( 'stripslashes', $value );
				} else {
					$value = stripslashes( $value );
				}
				
				if($option['type']=='variant'){
					continue;
				}

				switch ( $option['type'] ) {
					case 'checkbox' :
					case 'radiobutton' :
						include_once( 'fields/class-product-option-field-list.php' );
						$field = new Product_Option_Field_List( $option, $value );
					break;
					case 'custom' :
					case 'custom_textarea' :
					case 'custom_price' :
					case 'custom_letters_only' :
					case 'custom_digits_only' :
					case 'custom_letters_or_digits' :
					case 'custom_email' :
					case 'custom_date' :
					case 'input_multiplier' :
						include_once( 'fields/class-product-option-field-custom.php' );
						$field = new Product_Option_Field_Custom( $option, $value );
					break;
					case 'select' :
					case 'variant' :
						include_once( 'fields/class-product-option-field-select.php' );
						$field = new Product_Option_Field_Select( $option, $value );
					break;
					case 'file_upload' :
						include_once( 'fields/class-product-option-field-file-upload.php' );
						$field = new Product_Option_Field_File_Upload( $option, $value, $test );
					break;
				}

				$data = $field->get_cart_item_data();

				if ( is_wp_error( $data ) ) {
					if ( version_compare( WC_VERSION, '2.3.0', '<' ) ) {
						$this->add_error( $data->get_error_message() );
					} else {
						// Throw exception for add_to_cart to pickup
						throw new Exception( $data->get_error_message() );
					}
				} elseif ( $data ) {
					$cart_item_meta['options'] = array_merge( $cart_item_meta['options'], apply_filters( 'woocommerce_product_option_cart_item_data', $data, $option, $product_id, $post_data ) );
				}
			}
		}

		return $cart_item_meta;
	}

	/**
	 * validate_add_cart_item function.
	 *
	 * @access public
	 * @param mixed $passed
	 * @param mixed $product_id
	 * @param mixed $qty
	 * @return bool
	 */
	public function validate_add_cart_item( $passed, $product_id, $qty, $post_data = null ) {
		if ( is_null( $post_data ) && isset( $_POST ) ) {
			$post_data = $_POST;
		}

		$product_options = get_product_options( $product_id );

		if ( is_array( $product_options ) && ! empty( $product_options ) ) {
			include_once( 'fields/abstract-class-product-option-field.php' );

			foreach ( $product_options as $option ) {

				$value = isset( $post_data[ 'option-' . $option['field-name'] ] ) ? $post_data[ 'option-' . $option['field-name'] ] : '';

				if ( is_array( $value ) ) {
					$value = array_map( 'stripslashes', $value );
				} else {
					$value = stripslashes( $value );
				}

				if($option['parent']!=-1){
					$option['required'] = 0;
				}

				switch ( $option['type'] ) {
					case "checkbox" :
					case "radiobutton" :
						include_once( 'fields/class-product-option-field-list.php' );
						$field = new Product_Option_Field_List( $option, $value );
					break;
					case "custom" :
					case "custom_textarea" :
					case "custom_price" :
					case "custom_letters_only" :
					case "custom_digits_only" :
					case "custom_letters_or_digits" :
					case "custom_email" :
					case "input_multiplier" :
						include_once( 'fields/class-product-option-field-custom.php' );
						$field = new Product_Option_Field_Custom( $option, $value );
					break;
					case "select" :
					case "variant" :
						include_once( 'fields/class-product-option-field-select.php' );
						$field = new Product_Option_Field_Select( $option, $value );
					break;
					case "file_upload" :
						include_once( 'fields/class-product-option-field-file-upload.php' );
						$field = new Product_Option_Field_File_Upload( $option, $value );
					break;
				}

				$data = $field->validate();

				if ( is_wp_error( $data ) ) {
					$this->add_error( $data->get_error_message() );
					return false;
				}

				do_action( 'woocommerce_validate_posted_option_data', $option );
			}
		}

		return $passed;
	}

	/**
	 * Add meta to orders
	 *
	 * @access public
	 * @param mixed $item_id
	 * @param mixed $values
	 * @return void
	 */
	public function order_item_meta( $item_id, $values ) {
		if ( ! empty( $values['options'] ) ) {
			foreach ( $values['options'] as $option ) {

				$name = $option['name'];

				if ( $option['price'] > 0 && apply_filters( 'woocommerce_options_add_price_to_name', true ) ) {
					$name .= ' (' . strip_tags( wc_price( get_product_option_price_for_display ( $option['price'], $values[ 'data' ], true ) ) ) . ')';
				}

				woocommerce_add_order_item_meta( $item_id, $name, $option['value'] );
			}
		}
	}

	/**
	 * Re-order
	 */
	public function re_add_cart_item_data( $cart_item_meta, $product, $order ) {
		// Disable validation
		remove_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_cart_item' ), 10, 3 );

		// Get option data
		$product_options = get_product_options( $product['product_id'] );

		if ( empty( $cart_item_meta['options'] ) ) {
			$cart_item_meta['options'] = array();
		}

		if ( is_array( $product_options ) && ! empty( $product_options ) ) {
			include_once( 'fields/abstract-class-product-option-field.php' );

			foreach ( $product_options as $option ) {
				$value = '';
				$field = '';

				switch ( $option['type'] ) {
					case 'checkbox' :
					case 'radiobutton' :
						include_once( 'fields/class-product-option-field-list.php' );

						$value = array();

						foreach ( $product['item_meta'] as $key => $meta ) {
							if ( stripos( $key, $option['name'] ) === 0 ) {
								if ( 1 < count( $meta ) ) {
									$value[] = array_map( 'sanitize_title', $meta );
								} else {
									$value[] = sanitize_title( $meta[0] );
								}
							}
						}

						if ( empty( $value ) ) {
							continue;
						}

						$field = new Product_Option_Field_List( $option, $value );
					break;
					case 'select' :
					case 'variant' :
						include_once( 'fields/class-product-option-field-select.php' );

						$value = '';

						foreach ( $product['item_meta'] as $key => $meta ) {
							if ( stripos( $key, $option['name'] ) === 0 ) {
								$value = sanitize_title( $meta[0] );
							}
						}

						if ( empty( $value ) ) {
							continue;
						}

						$chosen_option = '';
						$loop          = 0;

						foreach ( $option['options'] as $option ) {
							$loop++;
							if ( sanitize_title( $option['label'] ) == $value ) {
								$value = $value . '-' . $loop;
								break;
							}
						}

						$field = new Product_Option_Field_Select( $option, $value );
					break;
					case 'custom' :
					case 'custom_textarea' :
					case 'custom_price' :
					case 'input_multiplier' :
						include_once( 'fields/class-product-option-field-custom.php' );

						$value = array();

						foreach ( $product['item_meta'] as $key => $meta ) {
							foreach ( $option['options'] as $option ) {
								if ( stripos( $key, $option['name'] ) === 0 && stristr( $key, $option['label'] ) ) {
									$value[ sanitize_title( $option['label'] ) ] = $meta[0];
								}
							}
						}

						if ( empty( $value ) ) {
							continue;
						}

						$field = new Product_Option_Field_Custom( $option, $value );
					break;
					case 'file_upload' :
						include_once( 'fields/class-product-option-field-file-upload.php' );

						$value = array();

						foreach ( $product['item_meta'] as $key => $meta ) {
							foreach ( $option['options'] as $option ) {
								if ( stripos( $key, $option['name'] ) === 0 && stristr( $key, $option['label'] ) ) {
									$value[ sanitize_title( $option['label'] ) ] = $meta[0];
								}
							}
						}

						if ( empty( $value ) ) {
							continue;
						}

						$field = new Product_Option_Field_File_Upload( $option, $value );
					break;
				}

				// make sure a field is set (if not it could be product with no add-ons)
				if ( $field ) {

					$data = $field->get_cart_item_data();

					if ( is_wp_error( $data ) ) {
						$this->add_error( $data->get_error_message() );
					} elseif ( $data ) {
						// get the post data
						$post_data = $_POST;

						$cart_item_meta['options'] = array_merge( $cart_item_meta['options'], apply_filters( 'woocommerce_product_option_reorder_cart_item_data', $data, $option, $product['product_id'], $post_data ) );
					}
				}
			}
		}

		return $cart_item_meta;
	}
	
	public function rf_add_cart_surcharge( $cart_object ) {
		global $woocommerce;
		$spfee = 0.00; // initialize special fee
		$spfeeperprod = 0.00; //special fee per product
		$option_fee = 0.00;
		
		$chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
		$chosen_shipping = $chosen_methods[0];
		
		foreach ( $cart_object->cart_contents as $key => $value ) {
			$proid = $value['product_id']; //get the product id from cart
			$quantiy = $value['quantity']; //get quantity from cart
			$itmprice = $value['data']->price; //get product price
			
			if($chosen_shipping!='local_pickup:2'){
				$_enable_handling = get_post_meta( $proid, '_enable_handling', true );
				if($_enable_handling=='Yes'){
					$_handling_fee = floatval(get_post_meta( $proid, '_handling', true ));
					if($_handling_fee)
						$spfee += $_handling_fee;
				}
			}
			
			$cqty = (int)$value['quantity'];
			if(isset($value['options']) && count($value['options'])>0){
				foreach ( $value['options'] as $option ) {
					if ( $option['price'] > 0 ) { 
						$option_fee += (isset($option['price_prefix']) && $option['price_prefix']==2) ? $option['price'] : $option['price']*$cqty;
					}
				}
			}
			
			if(isset($value['discounts']) && $value['discounts']['discounted']>0){
				if ( ! empty( $value['addons'] )){			
				foreach ( $value['addons'] as $addon ) {
						if ( $addon['price'] > 0 ) {
							$option_fee += (isset($addon['onesetup']) && $addon['onesetup']==1) ? (float)$addon['price'] : (float)$addon['price']*$cqty;
						}
					}
				}
			}
		}
	
		if($option_fee > 0 ) {
			$woocommerce->cart->add_fee( 'Product Option Total', $option_fee, true, '' );
		}
		
		if($spfee > 0 ) {
			$woocommerce->cart->add_fee( 'Handling fee', $spfee, true, 'standard' );
		}
	
	}
	
	public function isa_woo_cart_attribute_values($cart_item, $cart_item_key){
 
		$item_data = $cart_item_key['data'];
		$attributes = $item_data->get_attributes();
		 
		if ( ! $attributes ) {
			return $cart_item;
		}
		 
		$out = $cart_item . '<style type="text/css">';
		 
		$count = count($attributes);
		 
		$i = 0;
		foreach ( $attributes as $attribute ) {
	  
			if ( $attribute['is_taxonomy'] ) {
				// skip variations
					if ( $attribute['is_variation'] ) {
						  continue;
				}
	 
				// backwards compatibility
				 
				$product_id = $item_data->id;
				$terms = wp_get_post_terms( $product_id, $attribute['name'], 'all' );
				  
				// get the taxonomy
				$tax = $terms[0]->taxonomy;
				  
				// get the tax object
				$tax_object = get_taxonomy($tax);
				  
				// get tax label
				if ( isset ($tax_object->labels->name) ) {
					$tax_label = $tax_object->labels->name;
				} elseif ( isset( $tax_object->label ) ) {
					$tax_label = $tax_object->label;
				}
				  
				foreach ( $terms as $term ) {
					$out .= '.woocommerce td.product-name dl.variation .variation-'.$tax_label . '{display:none;}';
				}
			 
				$i++;
				// end for taxonomies
		 
			} else {
	 
				// not a taxonomy
				 
				$out .= '.woocommerce td.product-name dl.variation .variation-'.$attribute['name'] . '{display:none;}';
			 
				if ( $count > 1 && ( $i < ($count - 1) ) ) {
					$out .= ', ';
				}
			 
				$i++;
				 
			}
		}
		echo $out.'</style>';
	}
	
	public function custom_woocommerce_hidden_order_itemmeta($arr) {
		$arr[] = 'frame_data';
		return $arr;
	}
}

$GLOBALS['Product_Option_Cart'] = new Product_Option_Cart();
