<div class="<?php if ( 1 == $required ) echo 'rrequired-product-option'; ?> product-option product-option-<?php echo sanitize_title( $name ); ?> <?php echo sanitize_title( $option['option-selector'] ); ?> <?php echo ($option['parent']!='-1')?'dependent-child':'';?> <?php echo $relatedOptons;?>" data-parent="<?php echo $option['parent'];?>" data-index="<?php echo $option['data-index'];?>" data-optiontype="<?php echo $option['type'];?>" data-related="<?php echo $related;?>">

	<?php do_action( 'wc_product_option_start', $option ); ?>

	<?php if ( $name ) : ?>
		<h3 class="option-name"><?php echo wptexturize( $name ); ?> <?php if ( 1 == $required ) echo '<abbr class="required" title="' . __( 'Required field', 'woocommerce-product-options-adv' ) . '">*</abbr>'; ?></h3>
	<?php endif; ?>

	<?php if ( $description ) : ?>
		<?php echo '<div class="option-description">' . wpautop( wptexturize( $description ) ) . '</div>'; ?>
	<?php endif; ?>

	<?php do_action( 'wc_product_option_options', $option ); ?>
