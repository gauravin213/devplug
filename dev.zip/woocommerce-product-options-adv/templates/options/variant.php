<?php

$loop = 0;
$current_value = isset( $_POST['option-' . sanitize_title( $option['field-name'] ) ] ) ? wc_clean( $_POST[ 'option-' . sanitize_title( $option['field-name'] ) ] ) : '';
?>
<p class="form-row form-row-wide option-wrap-<?php echo sanitize_title( $option['field-name'] ); ?>">
    
	<select class="option option-select option-variant" name="option-<?php echo sanitize_title( $option['field-name'] ); ?>" data-id="<?php echo $option['data-index']; ?>" autocomplete="off">

		<?php if ( ! isset( $option['required'] ) ) : ?>
			<option value=""><?php _e('None', 'woocommerce-product-options-adv'); ?></option>
		<?php else : ?>
			<option value=""><?php _e('Select an option...', 'woocommerce-product-options-adv'); ?></option>
		<?php endif; ?>

		<?php foreach ( $option['options'] as $_option ) :
			$loop ++;
			$price = $_option['price'] > 0 ? ' (' . wc_price( get_product_option_price_for_display( $_option['price'] ) ) . ')' : '';
			$product_variation = new WC_Product_Variation($_option['min']);
		
			$variant_price = $product_variation->regular_price;
			$variant_priceDisplay = ' ('.wc_price($variant_price).')';
            $var_key = $var_val = '';
					if(!empty($product_variation->get_variation_attributes())){
					   foreach($product_variation->get_variation_attributes() as $key=> $val) 
					   {
					      $var_key = str_replace("attribute_", '', $key);
					      $var_val = $val;
					   }
					   if($var_key !='' && $var_val !='')
					   {
					     $var_term = get_term_by('slug',$var_val , $var_key);
					     if(!empty($var_term)){
					        $variation_title = $var_term->name;
					     }else{
					        $variation_title = $var_val;
					        $_option['label'] = $var_val;
					     }
					   }
					}
			
			if($variation_title==""){
			   $variation_title = $_option['label'];
			}
			?>
			<option data-variant-id="<?php echo (int)$_option['min']; ?>" data-price-prefix="<?php echo esc_attr( $_option['price_prefix'] ); ?>" data-raw-price="0" data-price="0" value="<?php echo sanitize_title( $_option['label'] ) . '-' . $loop; ?>" <?php selected( $current_value, sanitize_title( $_option['label'] ) . '-' . $loop ); ?> data-value='<?php echo $_option['label']; ?>'><?php echo wptexturize( $variation_title ) . $variant_priceDisplay ?></option>
		<?php endforeach; ?>

	</select>
</p>