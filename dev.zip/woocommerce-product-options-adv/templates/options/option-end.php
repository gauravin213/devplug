	<?php do_action( 'wc_product_option_end', $option ); ?>

	<div class="clear"></div>
</div>