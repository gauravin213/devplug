<?php

$loop = 0;
$current_value = isset( $_POST['option-' . sanitize_title( $option['field-name'] ) ] ) ? wc_clean( $_POST[ 'option-' . sanitize_title( $option['field-name'] ) ] ) : '';
?>
<p class="form-row form-row-wide option-wrap-<?php echo sanitize_title( $option['field-name'] ); ?>">
	<select class="option option-select" name="option-<?php echo sanitize_title( $option['field-name'] ); ?>" data-id="<?php echo $option['data-index']; ?>" autocomplete="off">

		<?php if ( ! isset( $option['required'] ) ) : ?>
			<option value=""><?php _e('None', 'woocommerce-product-options-adv'); ?></option>
		<?php else : ?>
			<option value=""><?php _e('Select an option...', 'woocommerce-product-options-adv'); ?></option>
		<?php endif; ?>

		<?php foreach ( $option['options'] as $_option ) :
		  //  echo '<pre>';print_r($_option);echo '</pre>';
			$loop ++;
			$price = $_option['price'] > 0 ? ' (' . wc_price( get_product_option_price_for_display( $_option['price'] ) ) . ')' : '';
			?>
			<option data-price-prefix="<?php echo esc_attr( $_option['price_prefix'] ); ?>" data-raw-price="<?php echo esc_attr( $_option['price'] ); ?>" data-price="<?php echo get_product_option_price_for_display( $_option['price'] ); ?>" value="<?php echo sanitize_title( $_option['label'] ) . '-' . $loop; ?>" <?php selected( $current_value, sanitize_title( $_option['label'] ) . '-' . $loop ); ?> data-value="<?php echo wptexturize( $_option['label'] ); ?>"><?php echo wptexturize( $_option['label'] ) . $price ?></option>
		<?php endforeach; ?>

	</select>
</p>