<style type="text/css">
#product-addons-total{
	display:none !important;
}
form.cart .variations{
	display:none;
}
</style>
<script type="text/javascript">
jQuery(document).ready(function(){
	var product_id = <?php echo $product_id;?>;
	var plugin_url = '<?php echo $plugin_url;?>';
	
	jQuery('.option-custom-date').datepicker();
	
	var pageLoaded = 0;
	setTimeout(function(){pageLoaded++},3000);
	jQuery(document).on('change', '.product-option.relatedOption select.option-select', function(){
		if(pageLoaded==0){return;}

		var selectedVal = jQuery(this).val().trim();
		var parentID = jQuery(this).attr('data-id');
		var variantID = product_id;
		if(selectedVal){
			var parentVal = jQuery('option:selected',this).attr('data-value').trim();
			parentVal = parentVal.replace("×","x");
			if(jQuery(this).hasClass('option-variant')){
				variantID = jQuery('option:selected',this).attr('data-variant-id');
				if(variantID){
					jQuery('.variations select[name^="attribute_"]:first').val(parentVal).change();
				}
			}

			jQuery.ajax( {
				type: 'POST',
				url:  woocommerce_options_params.ajax_url,
				data: {
					action: 'wc_product_options_get_child',
					parent_id: parentID,
					parent_value: parentVal,
					product_id: product_id
				},
				beforeSend: function(){
					jQuery('.product-option-loading').remove();
					jQuery('.product-option[data-index="'+parentID+'"] select').after('<img class="product-option-loading" src="'+plugin_url+'/assets/images/reload.gif"/>');
					hideChildOption(parentID);
					jQuery('input[name="quantity"]').trigger( 'change' );
				},
				complete: function(){
					jQuery('.product-option-loading').remove();
				},
				success: function( code ) {
					result = jQuery.parseJSON( code );
					if ( result.result == 'SUCCESS' ) {
						jQuery.each(result['product_options'], function(optionIndex,optionValues){
							var optionType = jQuery('.product-option[data-index="'+optionIndex+'"]').attr('data-optiontype');
							jQuery('.product-option[data-index="'+optionIndex+'"]').show();
							
							if(optionType=='select'){
								jQuery('.product-option[data-index="'+optionIndex+'"] select').val('');
								jQuery('.product-option[data-index="'+optionIndex+'"] select option:not([value=""])').hide();
								if(optionValues.length>0){
									jQuery.each(optionValues, function(optIndex, optValue){
										jQuery('.product-option[data-index="'+optionIndex+'"] select option[value="'+optValue+'"]').show();
									});
								}
							}
							else{
								jQuery('.product-option[data-index="'+optionIndex+'"] input').removeAttr('disabled');
							}
						});
					} else {
					}
				},
				error: function() {
				}
			});
		}
		else{
			hideChildOption(parentID);
		}
	});
	
	function hideChildOption(parentID){
		var optionsRelated = jQuery('.product-option[data-index="'+parentID+'"]').attr('data-related').split('_');
		if(optionsRelated){
			jQuery.each(optionsRelated, function(i,j){
				var optionType = jQuery('.product-option[data-index="'+j+'"]').attr('data-optiontype');
				//jQuery('.product-option[data-index="'+j+'"]').hide();
				jQuery('.product-option[data-index="'+j+'"] input').attr('disabled',true);
				if(optionType=='select'){
					hideChildOption(j);
					jQuery('.product-option[data-index="'+j+'"] select').val('');
					jQuery('.product-option[data-index="'+j+'"] select option:not([value=""])').hide();
				}
				else if(optionType=='radiobutton' || optionType=='checkbox'){
					jQuery('.product-option[data-index="'+j+'"] input[type="radio"]').removeAttr('checked');
				}
				else{
					jQuery('.product-option[data-index="'+j+'"] input').val('');
				}
			});
		}
	}
});
</script>