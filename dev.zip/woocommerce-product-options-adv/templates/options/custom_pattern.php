<?php foreach ( $option['options'] as $key => $_option ) :
	$options_key     = 'option-' . sanitize_title( $option['field-name'] );
	$option_key    = empty( $_option['label'] ) ? $key : sanitize_title( $_option['label'] );
	$current_value = isset( $_POST[ $options_key ] ) && isset( $_POST[ $options_key ][ $option_key ] ) ? wc_clean( $_POST[ $options_key ][ $option_key ] ) : '';
	$price         = $_option['price'] > 0 ? '(' . wc_price( get_product_option_price_for_display( $_option['price'] ) ) . ')' : '';
	?>

	<p class="form-row form-row-wide option-wrap-<?php echo sanitize_title( $option['field-name'] ); ?>">
		<?php if ( ! empty( $_option['label'] ) ) : ?>
			<label><?php echo wptexturize( $_option['label'] ) . ' ' . $price; ?></label>
		<?php endif; ?>
		<input type="text" pattern="<?php echo esc_attr( $pattern ); ?>" title="<?php echo esc_attr( $title ); ?>" class="input-text option option-custom option-custom-pattern" data-raw-price="<?php echo esc_attr( $_option['price'] ); ?>" data-price="<?php echo get_product_option_price_for_display( $_option['price'] ); ?>" name="<?php echo $options_key ?>[<?php echo $option_key; ?>]" value="<?php echo esc_attr( $current_value ); ?>" <?php if ( ! empty( $_option['max'] ) ) echo 'maxlength="' . $_option['max'] .'"'; ?> />
	</p>

<?php endforeach; ?>