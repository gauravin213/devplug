<?php foreach ( $option['options'] as $key => $_option ) :

	$price = ($_option['price']>0) ? ' (' . wc_price( get_product_option_price_for_display( $_option['price'] ) ) . ')' : '';

	if ( empty( $_option['label'] ) ) : ?>

		<p class="form-row form-row-wide option-wrap-<?php echo sanitize_title( $option['field-name'] ); ?>">
			<input type="file" class="input-text option" data-price="<?php echo get_product_option_price_for_display( $_option['price'] ); ?>" name="option-<?php echo sanitize_title( $option['field-name'] ); ?>-<?php echo sanitize_title( $_option['label'] ); ?>" /> <small><?php echo sprintf( __( '(max file size %s)', 'woocommerce-product-options-adv' ), $max_size ) ?></small>
		</p>

	<?php else : ?>

		<p class="form-row form-row-wide option-wrap-<?php echo sanitize_title( $option['field-name'] ); ?>">
			<label><?php echo wptexturize( $_option['label'] ) . ' ' . $price; ?> <input type="file" class="input-text option" data-raw-price="<?php echo esc_attr( $_option['price'] ); ?>" data-price="<?php echo get_product_option_price_for_display( $_option['price'] ); ?>" name="option-<?php echo sanitize_title( $option['field-name'] ); ?>-<?php echo sanitize_title( $_option['label'] ); ?>" /> <small><?php echo sprintf( __( '(max file size %s)', 'woocommerce-product-options-adv' ), $max_size ) ?></small></label>
		</p>

	<?php endif; ?>

<?php endforeach; ?>