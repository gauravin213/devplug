<?php
/*
Plugin Name: WooCommerce Advanced Product Options
Plugin URI: http://wordpress.org/plugins/
Description: WooCommerce Advanced Product Options.
Version: 1.0
Author: Neshmedia-BD
Author URI: http://www.neshmedia-bd.com

License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}


if ( is_woocommerce_active() ) {

	/**
	 * Main class
	 */
	class WC_Product_Options {

		/**
		 * Constructor
		 */
		public function __construct() {
			if ( is_admin() ) {
				include_once( 'admin/class-product-option-admin.php' );
				include_once( 'admin/class-product-shipping-option.php' );
			}

			include_once( 'classes/class-product-option-display.php' );
			include_once( 'classes/class-product-option-cart.php' );
			include_once( 'classes/class-wc-option-ajax.php' );

			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );
			add_action( 'init', array( $this, 'init_post_types' ), 20 );
		}

		/**
		 * Localisation
		 */
		public function load_plugin_textdomain() {
			load_plugin_textdomain( 'woocommerce-product-options-adv', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Init post types used for options
		 */
		public function init_post_types() {
			register_post_type( "global_product_option",
				array(
					'public'              => false,
					'show_ui'             => false,
					'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => false,
					'exclude_from_search' => true,
					'hierarchical'        => false,
					'rewrite'             => false,
					'query_var'           => false,
					'supports'            => array( 'title' ),
					'show_in_nav_menus'   => false
				)
			);

			register_taxonomy_for_object_type( 'product_cat', 'global_product_option' );
		}
	}

	new WC_Product_Options();

	/**
	 * Gets options assigned to a product by ID
	 *
	 * @param  int $post_id ID of the product to get options for
	 * @param  string $prefix for option field names. Defaults to postid-
	 * @param  bool $inc_parent Set to false to not include parent product options.
	 * @param  bool $inc_global Set to false to not include global options.
	 * @return array array of options
	 */
	function get_product_options( $post_id, $prefix = false, $inc_parent = true, $inc_global = true ) {
		if ( ! $post_id ) {
			return array();
		}

		$options        = array();
		$raw_options    = array();
		$product_terms = apply_filters( 'get_product_options_product_terms', wp_get_post_terms( $post_id, 'product_cat', array( 'fields' => 'ids' ) ), $post_id );
		$exclude       = get_post_meta( $post_id, '_product_options_exclude_global', true );

		// Product Parent Level Options
		if ( $inc_parent && $parent_id = wp_get_post_parent_id( $post_id ) ) {
			$raw_options[10]['parent'] = apply_filters( 'get_parent_product_options_fields', get_product_options( $parent_id, $parent_id . '-', false, false ), $post_id, $parent_id );
		}

		// Product Level Options
		$raw_options[10]['product'] = apply_filters( 'get_product_options_fields', array_filter( (array) get_post_meta( $post_id, '_product_options', true ) ), $post_id );

		// Global level options (all products)
		if ( '1' !== $exclude && $inc_global ) {
			$args = array(
				'posts_per_page'   => -1,
				'orderby'          => 'meta_value',
				'order'            => 'ASC',
				'meta_key'         => '_priority',
				'post_type'        => 'global_product_option',
				'post_status'      => 'publish',
				'suppress_filters' => true,
				'meta_query' => array(
					array(
						'key'   => '_all_products',
						'value' => '1',
					)
				)
			);

			$global_options = get_posts( $args );

			if ( $global_options ) {
				foreach ( $global_options as $global_option ) {
					$priority                                     = get_post_meta( $global_option->ID, '_priority', true );
					$raw_options[ $priority ][ $global_option->ID ] = apply_filters( 'get_product_options_fields', array_filter( (array) get_post_meta( $global_option->ID, '_product_options', true ) ), $global_option->ID );
				}
			}

			// Global level options (categories)
			if ( $product_terms ) {
				$args = apply_filters( 'get_product_options_global_query_args', array(
					'posts_per_page'   => -1,
					'orderby'          => 'meta_value',
					'order'            => 'ASC',
					'meta_key'         => '_priority',
					'post_type'        => 'global_product_option',
					'post_status'      => 'publish',
					'suppress_filters' => true,
					'tax_query'        => array(
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'id',
							'terms'            => $product_terms,
							'include_children' => false
						)
					)
				), $product_terms );

				$global_options = get_posts( $args );

				if ( $global_options ) {
					foreach ( $global_options as $global_option ) {
						$priority                                     = get_post_meta( $global_option->ID, '_priority', true );
						$raw_options[ $priority ][ $global_option->ID ] = apply_filters( 'get_product_options_fields', array_filter( (array) get_post_meta( $global_option->ID, '_product_options', true ) ), $global_option->ID );
					}
				}
			}

		}

		ksort( $raw_options );

		foreach ( $raw_options as $option_group ) {
			if ( $option_group ) {
				foreach ( $option_group as $option ) {
					$options = array_merge( $options, $option );
				}
			}
		}

		// Generate field names with unqiue prefixes
		if ( ! $prefix ) {
			$prefix = apply_filters( 'product_options_field_prefix', "{$post_id}-", $post_id );
		}

		// Let's avoid exceeding the suhosin default input element name limit of 64 characters
		$max_option_name_length = 45 - strlen( $prefix );

		// if the product_options_field_prefix filter results in a very long prefix, then
		// go ahead and enforce sanity, exceed the default suhosin limit, and just use
		// the prefix and the field counter for the input element name
		if ( $max_option_name_length < 0 ) {
			$max_option_name_length = 0;
		}

		$option_field_counter = 0;

		foreach ( $options as $option_key => $option ) {
			if ( empty( $option['name'] ) ) {
				unset( $options[ $option_key ] );
				continue;
			}
			if ( empty( $options[ $option_key ]['field-name'] ) ) {
				$option_name = substr( $option['name'], 0, $max_option_name_length );
				$options[ $option_key ]['field-name'] = sanitize_title( $prefix . $option_name . "-" . $option_field_counter );
				$options[ $option_key ]['option-selector'] = sanitize_title( 'oparent-'. $option['type'] . "-" . $option_field_counter );
				$options[ $option_key ]['data-index'] = sanitize_title( $option_field_counter );
				$option_field_counter++;
			}
		}

		return apply_filters( 'get_product_options', $options );
	}

	/**
	 * Display prices according to shop settings
	 *
	 * @param  float $price
	 *
	 * @return float
	 */
	function get_product_option_price_for_display( $price ) {
		global $product;

		if ( $price === '' || $price == '0' ) {
			return;
		}

		if ( is_object( $product ) ) {
			$tax_display_mode = get_option( 'woocommerce_tax_display_shop' );
			$display_price    = $tax_display_mode == 'incl' ? $product->get_price_including_tax( 1, $price ) : $product->get_price_excluding_tax( 1, $price );
		} else {
			$display_price    = $price;
		}

		return $display_price;
	}
}
