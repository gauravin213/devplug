<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product_Option_Admin class.
 */
class Product_Option_Admin {

	/**
	 * __construct function.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'styles' ), 100 );
		//add_action( 'admin_menu', array( $this, 'admin_menu' ), 9 );
		add_filter( 'woocommerce_screen_ids', array( $this, 'add_screen_id' ) );
		add_action( 'woocommerce_product_write_panel_tabs', array( $this, 'tab' ) );
		add_action( 'woocommerce_product_write_panels', array( $this, 'panel' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'process_meta_box' ), 1 );
	}

	/**
	 * Add menus
	 */
	public function admin_menu() {
		$page = add_submenu_page( 'edit.php?post_type=product', __( 'Global Options', 'woocommerce-product-options-adv' ), __( 'Global Options', 'woocommerce-product-options-adv' ), 'manage_woocommerce', 'global_options', array( $this, 'global_options_admin' ) );

		add_action( 'admin_print_styles-'. $page, array( &$this, 'admin_enqueue' ) );
	}

	/**
	 * admin_enqueue function.
	 *
	 * @return void
	 */
	public function admin_enqueue() {
		if ( version_compare( WC_VERSION, '2.3.0', '<' ) ) {
			wp_enqueue_script( 'chosen' );
		}
	}

	/**
	 * styles function.
	 *
	 * @return void
	 */
	public function styles() {
		wp_enqueue_style( 'woocommerce_product_options_css', plugins_url( basename( dirname( dirname( __FILE__ ) ) ) ) . '/assets/css/admin.css' );
	}

	/**
	 * Add screen id to WooCommerce
	 *
	 * @param array $screen_ids
	 */
	public function add_screen_id( $screen_ids ) {
		$screen_ids[] = 'product_page_global_options';

		return $screen_ids;
	}

	/**
	 * Controls the global options admin page
	 * @return void
	 */
	public function global_options_admin() {
		if ( ! empty( $_GET['add'] ) || ! empty( $_GET['edit'] ) ) {

			if ( $_POST ) {

				if ( $edit_id = $this->save_global_options() ) {
					echo '<div class="updated"><p>' . __( 'Option saved successfully', 'woocommerce-product-options-adv' ) . '</p></div>';
				}

				$reference      = woocommerce_clean( $_POST['option-reference'] );
				$priority       = absint( $_POST['option-priority'] );
				$objects        = ! empty( $_POST['option-objects'] ) ? array_map( 'absint', $_POST['option-objects'] ) : array();
				$product_options = array_filter( (array) $this->get_posted_product_options() );
			}

			if ( ! empty( $_GET['edit'] ) ) {

				$edit_id      = absint( $_GET['edit'] );
				$global_option = get_post( $edit_id );

				if ( ! $global_option ) {
					echo '<div class="error">' . __( 'Error: Global Option not found', 'woocommerce-product-options-adv' ) . '</div>';
					return;
				}

				$reference      = $global_option->post_title;
				$priority       = get_post_meta( $global_option->ID, '_priority', true );
				$objects        = (array) wp_get_post_terms( $global_option->ID, apply_filters( 'woocommerce_product_options_global_post_terms', array( 'product_cat' ) ), array( 'fields' => 'ids' ) );
				$product_options = array_filter( (array) get_post_meta( $global_option->ID, '_product_options', true ) );

				if ( get_post_meta( $global_option->ID, '_all_products', true ) == 1 ) {
					$objects[] = 0;
				}

			} elseif ( ! empty( $edit_id ) ) {

				$global_option   = get_post( $edit_id );
				$reference      = $global_option->post_title;
				$priority       = get_post_meta( $global_option->ID, '_priority', true );
				$objects        = (array) wp_get_post_terms( $global_option->ID, apply_filters( 'woocommerce_product_options_global_post_terms', array( 'product_cat' ) ), array( 'fields' => 'ids' ) );
				$product_options = array_filter( (array) get_post_meta( $global_option->ID, '_product_options', true ) );

				if ( get_post_meta( $global_option->ID, '_all_products', true ) == 1 ) {
					$objects[] = 0;
				}

			} else {

				$global_options_count = wp_count_posts( 'global_product_option' );
				$reference           = __( 'Global Option Group' ) . ' #' . ( $global_options_count->publish + 1 );
				$priority            = 10;
				$objects             = array( 0 );
				$product_options      = array();

			}

			include( 'html-global-admin-add.php' );
		} else {

			if ( ! empty( $_GET['delete'] ) && wp_verify_nonce( $_REQUEST['_wpnonce'], 'delete_option' ) ) {
				wp_delete_post( absint( $_GET['delete'] ), true );
				echo '<div class="updated"><p>' . __( 'Option deleted successfully', 'woocommerce-product-options-adv' ) . '</p></div>';
			}

			include( 'html-global-admin.php' );
		}
	}

	/**
	 * tab function.
	 *
	 * @return void
	 */
	public function tab() {
		?><li class="options_tab product_options"><a href="#product_options_data"><?php _e( 'Options', 'woocommerce-product-options-adv' ); ?></a></li><?php
	}

	/**
	 * panel function.
	 *
	 * @return void
	 */
	public function panel() {
		global $post;

		$product_options = array_filter( (array) get_post_meta( $post->ID, '_product_options', true ) );

		include( 'html-option-panel.php' );
	}

	/**
	 * Save global options
	 *
	 * @return bool success or failure
	 */
	public function save_global_options() {
		$edit_id        = ! empty( $_POST['edit_id'] ) ? absint( $_POST['edit_id'] ) : '';
		$reference      = woocommerce_clean( $_POST['option-reference'] );
		$priority       = absint( $_POST['option-priority'] );
		$objects        = ! empty( $_POST['option-objects'] ) ? array_map( 'absint', $_POST['option-objects'] ) : array();
		$product_options = $this->get_posted_product_options();

		if ( ! $reference ) {
			$global_options_count = wp_count_posts( 'global_product_option' );
			$reference           = __( 'Global Option Group' ) . ' #' . ( $global_options_count->publish + 1 );
		}

		if ( ! $priority && $priority !== 0 ) {
			$priority = 10;
		}

		if ( $edit_id ) {

			$edit_post               = array();
			$edit_post['ID']         = $edit_id;
			$edit_post['post_title'] = $reference;

			wp_update_post( $edit_post );
			wp_set_post_terms( $edit_id, $objects, 'product_cat', false );
			do_action( 'woocommerce_product_options_global_edit_options', $edit_post, $objects );

		} else {

			$edit_id = wp_insert_post( apply_filters( 'woocommerce_product_options_global_insert_post_args', array(
				'post_title'    => $reference,
				'post_status'   => 'publish',
				'post_type'		=> 'global_product_option',
				'tax_input'     => array(
					'product_cat' => $objects
				)
			), $reference, $objects ) );

		}

		if ( in_array( 0, $objects ) ) {
			update_post_meta( $edit_id, '_all_products', 1 );
		} else {
			update_post_meta( $edit_id, '_all_products', 0 );
		}

		update_post_meta( $edit_id, '_priority', $priority );
		update_post_meta( $edit_id, '_product_options', $product_options );

		return $edit_id;
	}

	/**
	 * Process meta box
	 *
	 * @param int $post_id
	 */
	public function process_meta_box( $post_id ) {
		// Save options as serialised array
		$product_options                = $this->get_posted_product_options();
		$product_options_exclude_global = isset( $_POST['_product_options_exclude_global'] ) ? 1 : 0;

		update_post_meta( $post_id, '_product_options', $product_options );
		update_post_meta( $post_id, '_product_options_exclude_global', $product_options_exclude_global );
	}


	/**
	 * Generate a filterable default new option option
	 *
	 * @return array
	 */
	public static function get_new_option_option() {
		$new_option_option = array(
			'label' => '',
			'parent' => '',
			'price_prefix' => '',
			'price' => '',
			'weight_prefix' => '',
			'weight' => '',
			'min' => '',
			'max' => ''
		);

		return apply_filters( 'woocommerce_product_options_new_option_option', $new_option_option );
	}

	/**
	 * Put posted option data into an array
	 *
	 * @return array
	 */
	private function get_posted_product_options() {
		$product_options = array();

		if ( isset( $_POST[ 'product_option_name' ] ) ) {
			 $option_name         = $_POST['product_option_name'];
			 $option_description  = $_POST['product_option_description'];
			 $option_type         = $_POST['product_option_type'];
			 $option_parent       = $_POST['product_option_parent'];
			 $option_position     = $_POST['product_option_position'];
			 $option_required     = isset( $_POST['product_option_required'] ) ? $_POST['product_option_required'] : array();

			 $option_option_label = $_POST['product_option_option_label'];
			 $option_option_price = $_POST['product_option_option_price'];
			 $option_option_price_prefix = $_POST['product_option_option_price_prefix'];
			 
			 $option_option_weight = $_POST['product_option_option_weight'];
			 $option_option_weight_prefix = $_POST['product_option_option_weight_prefix'];

			 $option_option_min   = $_POST['product_option_option_min'];
			 $option_option_max   = $_POST['product_option_option_max'];
			 
			 $option_option_parent   = $_POST['product_option_option_parent'];

			 for ( $i = 0; $i < sizeof( $option_name ); $i++ ) {

				if ( ! isset( $option_name[ $i ] ) || ( '' == $option_name[ $i ] ) ) {
					continue;
				}

				$option_options 	= array();
				$option_label  	= $option_option_label[ $i ];
				$option_price_prefix  	= $option_option_price_prefix[ $i ];
				$option_price  	= $option_option_price[ $i ];
				$option_weight_prefix  	= $option_option_weight_prefix[ $i ];
				$option_weight  	= $option_option_weight[ $i ];
				$option_min		= $option_option_min[ $i ];
				$option_max		= $option_option_max[ $i ];
				$option_parent_value	= $option_option_parent[ $i ];

				for ( $ii = 0; $ii < sizeof( $option_label ); $ii++ ) {
					$label 	= sanitize_text_field( stripslashes( $option_label[ $ii ] ) );
					$price_prefix 	= sanitize_text_field( stripslashes( $option_price_prefix[ $ii ] ) );
					$price 	= wc_format_decimal( sanitize_text_field( stripslashes( $option_price[ $ii ] ) ) );
					$weight_prefix 	= sanitize_text_field( stripslashes( $option_weight_prefix[ $ii ] ) );
					$weight 	= wc_format_decimal( sanitize_text_field( stripslashes( $option_weight[ $ii ] ) ) );
					$min	= sanitize_text_field( stripslashes( $option_min[ $ii ] ) );
					$max	= sanitize_text_field( stripslashes( $option_max[ $ii ] ) );
					$parent	= ($option_parent_value[ $ii ]);

					$option_options[] = array(
						'label' => $label,
						'parent' => $parent,
						'price_prefix' => $price_prefix,
						'price' => $price,
						'weight_prefix' => $weight_prefix,
						'weight' => $weight,
						'min'	=> $min,
						'max'	=> $max
					);
				}

				if ( sizeof( $option_options ) == 0 ) {
					continue; // Needs options
				}

				$data                = array();
				$data['name']        = sanitize_text_field( stripslashes( $option_name[ $i ] ) );
				$data['description'] = wp_kses_post( stripslashes( $option_description[ $i ] ) );
				$data['type']        = sanitize_text_field( stripslashes( $option_type[ $i ] ) );
				$data['parent']      = $option_parent[ $i ];
				$data['position']    = absint( $option_position[ $i ] );
				$data['options']     = $option_options;
				$data['required']    = isset( $option_required[ $i ] ) ? 1 : 0;

				// Add to array
				$product_options[] = apply_filters( 'woocommerce_product_options_save_data', $data, $i );
			}
		}

		if ( ! empty( $_POST['import_product_option'] ) ) {
			$import_options = maybe_unserialize( maybe_unserialize( stripslashes( trim( $_POST['import_product_option'] ) ) ) );

			if ( is_array( $import_options ) && sizeof( $import_options ) > 0 ) {
				$valid = true;

				foreach ( $import_options as $option ) {
					if ( ! isset( $option['name'] ) || ! $option['name'] ) {
						$valid = false;
					}
					if ( ! isset( $option['description'] ) ) {
						$valid = false;
					}
					if ( ! isset( $option['type'] ) ) {
						$valid = false;
					}
					if ( ! isset( $option['parent'] ) ) {
						$valid = false;
					}
					if ( ! isset( $option['position'] ) ) {
						$valid = false;
					}
					if ( ! isset( $option['options'] ) ) {
						$valid = false;
					}
					if ( ! isset( $option['required'] ) ) {
						$valid = false;
					}
				}

				if ( $valid ) {
					$product_options = array_merge( $product_options, $import_options );
				}
			}
		}

		uasort( $product_options, array( $this, 'options_cmp' ) );

		return $product_options;
	}

	/**
	 * Sort options
	 *
	 * @param  array $a
	 * @param  array $b
	 * @return bool
	 */
	private function options_cmp( $a, $b ) {
		if ( $a['position'] == $b['position'] ) {
			return 0;
		}

		return ( $a['position'] < $b['position'] ) ? -1 : 1;
	}
}

$GLOBALS['Product_Option_Admin'] = new Product_Option_Admin();
