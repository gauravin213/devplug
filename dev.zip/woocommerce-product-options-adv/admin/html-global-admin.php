<div class="wrap woocommerce">
	<div class="icon32 icon32-posts-product" id="icon-woocommerce"><br/></div>

    <h2><?php _e( 'Global Options', 'woocommerce-product-options-adv' ) ?> <a href="<?php echo add_query_arg( 'add', true, admin_url( 'edit.php?post_type=product&page=global_options' ) ); ?>" class="add-new-h2"><?php _e( 'Add Global Option', 'woocommerce-product-options-adv' ); ?></a></h2><br/>

	<table id="global-options-table" class="wp-list-table widefat" cellspacing="0">
		<thead>
			<tr>
				<th scope="col"><?php _e( 'Reference', 'woocommerce-product-options-adv' ); ?></th>
				<th><?php _e( 'Number of Fields', 'woocommerce-product-options-adv' ); ?></th>
				<th><?php _e( 'Priority', 'woocommerce-product-options-adv' ); ?></th>
				<th><?php _e( 'Applies to...', 'woocommerce-product-options-adv' ); ?></th>
				<th><?php _e( 'Actions', 'woocommerce-product-options-adv' ); ?></th>
			</tr>
		</thead>
		<tbody id="the-list">
			<?php
				$args = array(
					'posts_per_page'  => -1,
					'orderby'         => 'title',
					'order'           => 'ASC',
					'post_type'       => 'global_product_option',
					'post_status'     => 'any',
					'suppress_filters' => true
				);

				$global_options = get_posts( $args );

				if ( $global_options ) {
					foreach ( $global_options as $global_option ) {
						$reference      = $global_option->post_title;
						$priority       = get_post_meta( $global_option->ID, '_priority', true );
						$objects        = (array) wp_get_post_terms( $global_option->ID, apply_filters( 'woocommerce_product_options_global_post_terms', array( 'product_cat' ) ), array( 'fields' => 'ids' ) );
						$product_options = array_filter( (array) get_post_meta( $global_option->ID, '_product_options', true ) );
						if ( get_post_meta( $global_option->ID, '_all_products', true ) == 1 ) {
							$objects[] = 0;
						}
						?>
						<tr>
							<td><?php echo $reference; ?></td>
							<td><?php echo sizeof( $product_options ); ?></td>
							<td><?php echo $priority; ?></td>
							<td><?php

								if ( in_array( 0, $objects ) ) {
									_e( 'All Products', 'woocommerce-product-options-adv' );
								} else {
									$term_names = array();
									foreach ( $objects as $object_id ) {
										$term = get_term_by( 'id', $object_id, 'product_cat' );
										if ( $term ) {
											$term_names[] = $term->name;
										}
									}

									$term_names = apply_filters( 'woocommerce_product_options_global_display_term_names', $term_names, $objects );

									echo implode( ', ', $term_names );
								}

							?></td>
							<td>
								<a href="<?php echo add_query_arg( 'edit', $global_option->ID, admin_url( 'edit.php?post_type=product&page=global_options' ) ); ?>" class="button"><?php _e( 'Edit', 'woocommerce-product-options-adv' ); ?></a> <a href="<?php echo wp_nonce_url( add_query_arg( 'delete', $global_option->ID, admin_url( 'edit.php?post_type=product&page=global_options' ) ), 'delete_option' ); ?>" class="button"><?php _e( 'Delete', 'woocommerce-product-options-adv' ); ?></a>
							</td>
						</tr>
						<?php
					}
				} else {
					?>
					<tr>
						<td colspan="5"><?php _e( 'No global add-ons exists yet.', 'woocommerce-product-options-adv' ); ?> <a href="<?php echo add_query_arg( 'add', true, admin_url( 'edit.php?post_type=product&page=global_options' ) ); ?>"><?php _e( 'Add one?', 'woocommerce-product-options-adv' ); ?></a></td>
					</tr>
					<?php
				}
			?>
		</tbody>
	</table>
</div>
