<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'woocommerce_product_options_dimensions', 'wc_shipping_custom_option' );

function wc_shipping_custom_option() {
	global $thepostid;
	
	$_item_per_box = intval(get_post_meta( $thepostid, '_item_per_box', true ));
	
	$_additional_weight = get_post_meta( $thepostid, '_additional_weight', true );
	$_additional_length = get_post_meta( $thepostid, '_additional_length', true );
	$_additional_width = get_post_meta( $thepostid, '_additional_width', true );
	$_additional_height = get_post_meta( $thepostid, '_additional_height', true );
	$_items_per_box = get_post_meta( $thepostid, '_items_per_box', true );
	$additionalBoxes = is_array($_additional_weight) ? count($_additional_weight) : 0;
	
	echo '<div class="shipping_custom_options">';
		echo '<div class="dimension_container">';
			echo '<div class="item_counter">Item <span>1</span></div>';
			echo '<div class="item_dimension">';
			woocommerce_wp_text_input( array( 'id' => '_weight', 'label' => __( 'Weight', 'woocommerce' ) . ' (' . get_option( 'woocommerce_weight_unit' ) . ')', 'placeholder' => wc_format_localized_decimal( 0 ), 'desc_tip' => 'true', 'description' => __( 'Weight in decimal form', 'woocommerce' ), 'type' => 'text', 'data_type' => 'decimal' ) );
		?>
			<p class="form-field dimensions_field">
				<label for="product_length"><?php echo __( 'Dimensions', 'woocommerce' ) . ' (' . get_option( 'woocommerce_dimension_unit' ) . ')'; ?></label>
				<span class="wrap">
					<input id="product_length" placeholder="<?php esc_attr_e( 'Length', 'woocommerce' ); ?>" class="input-text wc_input_decimal" size="6" type="text" name="_length" value="<?php echo esc_attr( wc_format_localized_decimal( get_post_meta( $thepostid, '_length', true ) ) ); ?>" />
					<input placeholder="<?php esc_attr_e( 'Width', 'woocommerce' ); ?>" class="input-text wc_input_decimal" size="6" type="text" name="_width" value="<?php echo esc_attr( wc_format_localized_decimal( get_post_meta( $thepostid, '_width', true ) ) ); ?>" />
					<input placeholder="<?php esc_attr_e( 'Height', 'woocommerce' ); ?>" class="input-text wc_input_decimal last" size="6" type="text" name="_height" value="<?php echo esc_attr( wc_format_localized_decimal( get_post_meta( $thepostid, '_height', true ) ) ); ?>" />
				</span>
				<?php echo wc_help_tip( __( 'LxWxH in decimal form', 'woocommerce' ) ); ?>
			</p>
            </div>
            <div class="item_boxes">
            	<label><?php esc_attr_e( 'Item Per Box', 'woocommerce' ); ?></label>
            	<input placeholder="<?php esc_attr_e( 'Item Per Box', 'woocommerce' ); ?>" class="input-text wc_input_decimal last" size="6" type="text" name="_item_per_box" value="<?php echo $_item_per_box ? $_item_per_box : 1; ?>" />
            </div>
        </div>
        <?php
		if(count($additionalBoxes)){
			for($i=0;$i<$additionalBoxes;$i++){
				echo '<div class="dimension_container extra_dimension"><div class="item_counter">Item <span>'.($i+2).'</span></div><div class="item_dimension"><p class="form-field _weight_field "><label>Weight (lbs)</label><input class="short wc_input_decimal" style="" name="_additional_weight[]" value="'.$_additional_weight[$i].'" placeholder="0" type="text"></p><p class="form-field dimensions_field"><label>Dimensions (in)</label><span class="wrap"><input placeholder="Length" class="input-text wc_input_decimal" size="6" name="_additional_length[]" value="'.$_additional_length[$i].'" type="text"><input placeholder="Width" class="input-text wc_input_decimal" size="6" name="_additional_width[]" value="'.$_additional_width[$i].'" type="text"><input placeholder="Height" class="input-text wc_input_decimal last" size="6" name="_additional_height[]" value="'.$_additional_height[$i].'" type="text"></span></p></div><div class="item_boxes"><label>Item Per Box</label><input placeholder="Item Per Box" class="input-text wc_input_decimal last" size="6" name="_items_per_box[]" value="'.$_items_per_box[$i].'" type="text"><button class="remove_shipping_package button" type="button">Remove</button></div></div>';
			}
		}
		?>
	</div>
    <div class="shipping_custom_options_btns">
    	<button class="add_shipping_packages button" type="button">Add more packages</button>
    </div>
<style type="text/css">
#shipping_product_data > .options_group > ._weight_field,
#shipping_product_data > .options_group > .dimensions_field{
	display:none;
}
.dimension_container{
	position:relative;
}
.dimension_container .item_counter{
	float:left;
	width:60px;
	vertical-align:middle;
	padding-top:40px;
	padding-left:10px;
	font-weight:bold;
}
.dimension_container .item_dimension{
	float:left;
	width:60%;
	width:calc(100% - 200px);
}
.dimension_container .item_boxes{
	float:left;
	width:100px;
	vertical-align:middle;
	padding-top:20px;
}
.dimension_container .item_boxes > label{
	margin-left:-100px;
	padding-top:4px;
}
.dimension_container::after {
    clear: both;
    content: ".";
    display: block;
    height: 0;
    visibility: hidden;
}
.shipping_custom_options_btns{
	padding-left:10px;
}
.item_boxes > .remove_shipping_package{
	float:right;
	margin-top:10px;
}

.woocommerce_variable_attributes .form-row.hide_if_variation_virtual.form-row-first:first-child,
.woocommerce_variable_attributes .form-row.dimensions_field{
	display:none !important;
}
.form-row.custom_dimensions_field input {
    float: left;
    margin-right: 1%;
    width: 20%;
}
.variant_boxes .item_counter{
	font-weight:bold;
}
.shipping_custom_box_btns{
	clear:both;
}
</style>  
<script type="text/javascript">
jQuery(document).on('click', '.add_shipping_packages', function(){
	var totalItems = jQuery('.shipping_custom_options > .dimension_container').length;
	
	var sl = totalItems + 1;
	var html = '<div class="dimension_container extra_dimension"><div class="item_counter">Item <span>'+sl+'</span></div><div class="item_dimension"><p class="form-field _weight_field "><label>Weight (lbs)</label><input class="short wc_input_decimal" style="" name="_additional_weight[]" placeholder="0" type="text"></p><p class="form-field dimensions_field"><label>Dimensions (in)</label><span class="wrap"><input placeholder="Length" class="input-text wc_input_decimal" size="6" name="_additional_length[]" type="text"><input placeholder="Width" class="input-text wc_input_decimal" size="6" name="_additional_width[]" type="text"><input placeholder="Height" class="input-text wc_input_decimal last" size="6" name="_additional_height[]" type="text"></span></p></div><div class="item_boxes"><label>Item Per Box</label><input placeholder="Item Per Box" class="input-text wc_input_decimal last" size="6" name="_items_per_box[]" value="1" type="text"><button class="remove_shipping_package button" type="button">Remove</button></div></div>';
	
	jQuery('.shipping_custom_options').append(html);
});

jQuery(document).on('click', '.remove_shipping_package', function(){
	jQuery(this).parent().parent().remove();
	
	var totalItems = jQuery('.shipping_custom_options > .dimension_container.extra_dimension').length;
	if(totalItems > 0){
		var sl = 2;
		jQuery('.shipping_custom_options > .dimension_container.extra_dimension').each(function(){
			jQuery(this).find('.item_counter > span').text(sl);
			sl++;
		});
	}
});

jQuery(document).on('click', '.add_shipping_boxes', function(){
	var loop = jQuery(this).attr('data-loop');
	var totalItems = jQuery(this).parent().parent().find('.variant_boxes > .variant_box').length;
	
	var sl = totalItems + 1;
	var html = '<div class="variant_box extra_box"><p class="form-row form-row-first"><span class="item_counter">Item <span>'+sl+'</span></span></p><p class="form-row form-row-last"><label>Item Per Box</label><input placeholder="" class="input-text wc_input_decimal last" size="6" type="text" name="variable_items_per_box['+loop+'][]" value="1" /></p><p class="form-row custom_weight_field form-row-first"><label>Weight (lbs)</label><input type="text" size="5" name="variable_additional_weight['+loop+'][]" value="" placeholder="" class="wc_input_decimal" /></p><p class="form-row custom_dimensions_field form-row-last"><label for="product_length">Dimensions (L&times;W&times;H)</label><input id="product_additional_length" class="input-text wc_input_decimal" size="6" type="text" name="variable_additional_length['+loop+'][]" value="" placeholder="" /><input class="input-text wc_input_decimal" size="6" type="text" name="variable_additional_width['+loop+'][]" value="" placeholder="" /><input class="input-text wc_input_decimal last" size="6" type="text" name="variable_additional_height['+loop+'][]" value="" placeholder="" /><button class="remove_shipping_box button" type="button">Remove</button></p></div>';
	
	jQuery('.variant_boxes').append(html);
});

jQuery(document).on('click', '.remove_shipping_box', function(){
	jQuery(this).parent().parent().remove();
	
	var totalItems = jQuery('.variant_boxes > .variant_box.extra_box').length;
	if(totalItems > 0){
		var sl = 2;
		jQuery('.variant_boxes > .variant_box.extra_box').each(function(){
			jQuery(this).find('.item_counter > span').text(sl);
			sl++;
		});
	}
});
</script>  
	<?php
	echo '<hr>';
	$_enable_handling = get_post_meta( $thepostid, '_enable_handling', true );
	woocommerce_wp_radio( array( 
								'id' => '_enable_handling', 
								'label' => __( 'Enable Handling fee', 'woocommerce-shipping-option' ), 
								'description' => __( '', 'woocommerce-shipping-option' ) ,
								'value'     => !empty($_enable_handling) ? $_enable_handling : 'No',
								'options' => array(
									'Yes' => __('Yes', 'woocommerce-shipping-option'),
									'No' => __('No', 'woocommerce-shipping-option')
								)
							) );
							
	woocommerce_wp_text_input( array( 
								'id' => '_handling', 
								'label' => __( 'Handling fee', 'woocommerce-shipping-option' ) . ' (' . get_woocommerce_currency_symbol(get_option( 'woocommerce_currency' )) . ')', 
								'description' => __( '', 'woocommerce-shipping-option' ) 
							) );
							
	echo '<hr>';

}


add_action( 'woocommerce_process_product_meta', 'wc_shipping_custom_option_process_product_meta', 10, 2 );

/**
 * Save our custom product meta fields
 */
function wc_shipping_custom_option_process_product_meta( $post_id, $post ) {

	$is_virtual = isset( $_POST['_virtual'] ) ? 'yes' : 'no';

	// Dimensions
	if ( 'no' == $is_virtual ) {
		update_post_meta( $post_id, '_enable_handling',   stripslashes( $_POST['_enable_handling'] ) );
		update_post_meta( $post_id, '_handling',   stripslashes( $_POST['_handling'] ) );
		update_post_meta( $post_id, '_item_per_box',   stripslashes( $_POST['_item_per_box'] ) );
		
		update_post_meta( $post_id, '_additional_weight',   ( $_POST['_additional_weight'] ) );
		update_post_meta( $post_id, '_additional_length',   ( $_POST['_additional_length'] ) );
		update_post_meta( $post_id, '_additional_width',   ( $_POST['_additional_width'] ) );
		update_post_meta( $post_id, '_additional_height',   ( $_POST['_additional_height'] ) );
		update_post_meta( $post_id, '_items_per_box',   ( $_POST['_items_per_box'] ) );
	} else {
		update_post_meta( $post_id, '_enable_handling',   'No' );
		update_post_meta( $post_id, '_handling',   '' );
		update_post_meta( $post_id, '_item_per_box', '' );
		
		update_post_meta( $post_id, '_additional_weight', '' );
		update_post_meta( $post_id, '_additional_length', '' );
		update_post_meta( $post_id, '_additional_width', '' );
		update_post_meta( $post_id, '_additional_height', '' );
		update_post_meta( $post_id, '_items_per_box', '' );
	}

	// compensate for non-integral stock quantities enforced by WC core
	$product_type = empty( $_POST['product-type'] ) ? 'simple' : sanitize_title( stripslashes( $_POST['product-type'] ) );

}

add_action( 'woocommerce_variation_options_dimensions', 'wc_shipping_calculator_product_after_variable_attributes', 10, 3 );

function wc_shipping_calculator_product_after_variable_attributes( $loop, $variation_data, $variation ) {
	global $post;

	// add meta data to $variation_data array
	$variation_data = array_merge( get_post_meta( $variation->ID ), $variation_data );
	
	$_weight = (isset($variation_data['_weight'])) ? $variation_data['_weight'] : '';
	$_length = (isset($variation_data['_length'])) ? $variation_data['_length'] : '';
	$_width = (isset($variation_data['_width'])) ? $variation_data['_width'] : '';
	$_height = (isset($variation_data['_height'])) ? $variation_data['_height'] : '';

	$_item_per_box = (isset($variation_data['_item_per_box'])) ? (int)$variation_data['_item_per_box'][0] : '1';
	
	$_additional_weight = (isset($variation_data['_additional_weight'])) ? @unserialize($variation_data['_additional_weight'][0]) : array();
	$_additional_length = (isset($variation_data['_additional_length'])) ? @unserialize($variation_data['_additional_length'][0]) : array();
	$_additional_width = (isset($variation_data['_additional_width'])) ? @unserialize($variation_data['_additional_width'][0]) : array();
	$_additional_height = (isset($variation_data['_additional_height'])) ? @unserialize($variation_data['_additional_height'][0]) : array();
	$_items_per_box = (isset($variation_data['_items_per_box'])) ? @unserialize($variation_data['_items_per_box'][0]) : array();
	$additionalBoxes = is_array($_additional_weight) ? count($_additional_weight) : 0;
	//echo '<pre>';print_r($variation_data);echo '</pre>';
	?>
    <div class="variant_boxes kkkkkk">
    	<div class="variant_box">
            <p class="form-row form-row-first">
                <span class="item_counter">Item <span>1</span></span>
            </p>
            <p class="form-row form-row-last">
                <label><?php esc_attr_e( 'Item Per Box', 'woocommerce' ); ?></label>
                <input placeholder="<?php esc_attr_e( 'Item Per Box', 'woocommerce' ); ?>" class="input-text wc_input_decimal last" size="6" type="text" name="variable_item_per_box[<?php echo $loop; ?>]" value="<?php echo $_item_per_box ? $_item_per_box : 1; ?>" />
            </p>
            
            <p class="form-row custom_weight_field form-row-first">
                <label><?php echo __( 'Weight', 'woocommerce' ) . ' (' . esc_html( get_option( 'woocommerce_weight_unit' ) ) . ')'; ?> <?php echo wc_help_tip( __( 'Enter a weight for this variation or leave blank to use the parent product weight.', 'woocommerce' ) ); ?></a></label>



         		<input type="text" size="5" name="variable_weight[<?php echo $loop; ?>]" value="<?php if (is_array($_weight) && isset($_weight[0])) echo esc_attr( $_weight[0] ); else echo esc_attr( $_weight ); ?>" placeholder="" class="wc_input_decimal" />
            </p>
            <p class="form-row custom_dimensions_field form-row-last">
                <label for="product_length"><?php echo __( 'Dimensions (L&times;W&times;H)', 'woocommerce' ) . ' (' . esc_html( get_option( 'woocommerce_dimension_unit' ) ) . ')'; ?></label>
                <input id="product_length" class="input-text wc_input_decimal" size="6" type="text" name="variable_length[<?php echo $loop; ?>]" value="<?php if (is_array($_length) && isset($_length[0])) echo esc_attr( $_length[0] ); else echo esc_attr( $_length ); ?>" placeholder="" />
                <input class="input-text wc_input_decimal" size="6" type="text" name="variable_width[<?php echo $loop; ?>]" value="<?php if (is_array($_width) && isset($_width[0])) echo esc_attr( $_width[0] ); else echo esc_attr( $_width ); ?>" placeholder="" />
                <input class="input-text wc_input_decimal last" size="6" type="text" name="variable_height[<?php echo $loop; ?>]" value="<?php if (is_array($_height) && isset($_height[0])) echo esc_attr( $_height[0] ); else echo esc_attr( $_height ); ?>" placeholder="" />
            </p>
        </div>
        <?php
		if(count($additionalBoxes)){
			for($i=0;$i<$additionalBoxes;$i++){
				echo '<div class="variant_box extra_box"><p class="form-row form-row-first"><span class="item_counter">Item <span>'.($i+2).'</span></span></p><p class="form-row form-row-last"><label>Item Per Box</label><input placeholder="" class="input-text wc_input_decimal last" size="6" type="text" name="variable_items_per_box['.$loop.'][]" value="'.$_items_per_box[$i].'" /></p><p class="form-row custom_weight_field form-row-first"><label>Weight (lbs)</label><input type="text" size="5" name="variable_additional_weight['.$loop.'][]" value="'.$_additional_weight[$i].'" placeholder="" class="wc_input_decimal" /></p><p class="form-row custom_dimensions_field form-row-last"><label for="product_length">Dimensions (L&times;W&times;H)</label><input id="product_additional_length" class="input-text wc_input_decimal" size="6" type="text" name="variable_additional_length['.$loop.'][]" value="'.$_additional_length[$i].'" placeholder="" /><input class="input-text wc_input_decimal" size="6" type="text" name="variable_additional_width['.$loop.'][]" value="'.$_additional_width[$i].'" placeholder="" /><input class="input-text wc_input_decimal last" size="6" type="text" name="variable_additional_height['.$loop.'][]" value="'.$_additional_height[$i].'" placeholder="" /><button class="remove_shipping_box button" type="button">Remove</button></p></div>';
			}
		}
		?>
    </div>
    <div class="shipping_custom_box_btns">
    	<button class="add_shipping_boxes button" type="button" data-loop="<?php echo $loop;?>">Add more packages</button>
    </div>	       
	<?php
}

add_action( 'woocommerce_process_product_meta_variable', 'wc_custom_ship_calculator_process_product_meta_variable' );
add_action( 'woocommerce_ajax_save_product_variations',  'wc_custom_ship_calculator_process_product_meta_variable' );

function wc_custom_ship_calculator_process_product_meta_variable( $post_id ) {
	if ( isset( $_POST['variable_sku'] ) ) {

		$variable_post_id = isset( $_POST['variable_post_id'] ) ? $_POST['variable_post_id'] : array();
		$variable_item_per_box    = isset( $_POST['variable_item_per_box'] )    ? $_POST['variable_item_per_box'] : '1';
		
		$variable_additional_weight  = isset( $_POST['variable_additional_weight'] )  ? $_POST['variable_additional_weight'] : array();
		$variable_additional_length  = isset( $_POST['variable_additional_length'] )  ? $_POST['variable_additional_length'] : array();
		$variable_additional_width  = isset( $_POST['variable_additional_width'] )  ? $_POST['variable_additional_width'] : array();
		$variable_additional_height  = isset( $_POST['variable_additional_height'] )  ? $_POST['variable_additional_height'] : array();
		$variable_items_per_box  = isset( $_POST['variable_items_per_box'] )  ? $_POST['variable_items_per_box'] : array();

		// bail if $variable_post_id is not as expected
		if ( ! is_array( $variable_post_id ) ) {
			return;
		}

		$max_loop = max( array_keys( $variable_post_id ) );

		for ( $i = 0; $i <= $max_loop; $i++ ) {

			if ( ! isset( $variable_post_id[ $i ] ) ) continue;

			$variation_id = (int) $variable_post_id[ $i ];

			// Update area post meta
			if ( empty( $variable_item_per_box[ $i ] ) ) {
				delete_post_meta( $variation_id, '_item_per_box' );
			} else {
				update_post_meta( $variation_id, '_item_per_box', $variable_item_per_box[ $i ] );
			}

			// Update volume post meta
			if ( empty( $variable_additional_weight[ $i ] ) ) {
				delete_post_meta( $variation_id, '_additional_weight' );
			} else {
				update_post_meta( $variation_id, '_additional_weight', $variable_additional_weight[ $i ] );
			}
			if ( empty( $variable_additional_length[ $i ] ) ) {
				delete_post_meta( $variation_id, '_additional_length' );
			} else {
				update_post_meta( $variation_id, '_additional_length', $variable_additional_length[ $i ] );
			}
			if ( empty( $variable_additional_width[ $i ] ) ) {
				delete_post_meta( $variation_id, '_additional_width' );
			} else {
				update_post_meta( $variation_id, '_additional_width', $variable_additional_width[ $i ] );
			}
			if ( empty( $variable_additional_height[ $i ] ) ) {
				delete_post_meta( $variation_id, '_additional_height' );
			} else {
				update_post_meta( $variation_id, '_additional_height', $variable_additional_height[ $i ] );
			}
			if ( empty( $variable_items_per_box[ $i ] ) ) {
				delete_post_meta( $variation_id, '_items_per_box' );
			} else {
				update_post_meta( $variation_id, '_items_per_box', $variable_items_per_box[ $i ] );
			}
		}
	}
}