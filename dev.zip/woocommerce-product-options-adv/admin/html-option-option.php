<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<tr>
	<td><input class="variant_label" type="text" name="product_option_option_label[<?php echo $loop; ?>][]" value="<?php echo esc_attr( $opt['label'] ); ?>" placeholder="<?php esc_html_e( 'Default Label', 'woocommerce-product-options-adv'); ?>" style="display:<?php echo ($option['type']=='variant')?'none':'inline';?>" />
    <?php if(count($variations)){ ?>
    <select class="pr_variants" style="display:<?php echo ($option['type']=='variant')?'block':'none';?>">
    	<option value="">---</option>
    	<?php foreach($variations as $variation){ ?>
        	<option <?php if($opt['label']==$variation['variation_title']){echo 'selected="selected"';} ?> value="<?php echo $variation['variation_title']; ?>" data-variation-id="<?php echo $variation['variation_id']; ?>" data-variation-price="<?php echo $variation['variation_price']; ?>"><?php echo $variation['variation_title']; ?></option>
        <?php } ?>
    </select>
    <?php } ?>
    </td>
    <td class="parent_value"><select name="product_option_option_parent[<?php echo $loop; ?>][<?php echo $ok;?>][]" multiple="multiple">
    <?php
	if(isset($option['parent']) && $option['parent']!='-1' && (isset($parentOptionValues[$option['parent']]) && count($parentOptionValues[$option['parent']]))){
		foreach($parentOptionValues[$option['parent']] as $parentVal){
			?>
            <option <?php if(is_array($opt['parent']) && in_array($parentVal, $opt['parent'])){echo 'selected="selected"';} ?> value="<?php echo $parentVal; ?>"><?php echo $parentVal; ?></option>
            <?php
		}
	}
	?>
    </select></td>
	<td class="price_column"><select name="product_option_option_price_prefix[<?php echo $loop; ?>][]"><option value="1" <?php if($opt['price_prefix']==1){echo ' selected="selected"';}?>>+</option><option value="2" <?php if($opt['price_prefix']==2){echo ' selected="selected"';}?>>+(Once)</option></select><input type="text" name="product_option_option_price[<?php echo $loop; ?>][]" value="<?php echo esc_attr( wc_format_localized_price( $opt['price'] ) ); ?>" placeholder="0.00" class="wc_input_price" /></td>
    
    <td class="weight_column"><select name="product_option_option_weight_prefix[<?php echo $loop; ?>][]"><option value="1" <?php if($opt['weight_prefix']==1){echo ' selected="selected"';}?>>+</option><option value="2" <?php if($opt['weight_prefix']==2){echo ' selected="selected"';}?>>+(Once)</option></select><input type="text" name="product_option_option_weight[<?php echo $loop; ?>][]" value="<?php echo esc_attr(wc_format_decimal( $opt['weight'])); ?>" placeholder="0.00" class="wc_input_weight" /></td>

	<td class="minmax_column"><input class="variant_id" type="number" name="product_option_option_min[<?php echo $loop; ?>][]" value="<?php echo esc_attr( $opt['min'] ) ?>" placeholder="N/A" min="0" step="any" /></td>

	<td class="minmax_column"><input type="number" name="product_option_option_max[<?php echo $loop; ?>][]" value="<?php echo esc_attr( $opt['max'] ) ?>" placeholder="N/A" min="0" step="any" /></td>

	<td class="actions" width="1%"><button type="button" class="remove_option_option button">x</button></td>
</tr>