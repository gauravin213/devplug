<div id="product_options_data" class="panel woocommerce_options_panel wc-metaboxes-wrapper">
	<?php do_action( 'woocommerce-product-options-adv_panel_start' ); ?>

	<p class="toolbar">
		<a href="#" class="close_all"><?php _e( 'Close all', 'woocommerce-product-options-adv' ); ?></a> / <a href="#" class="expand_all"><?php _e( 'Expand all', 'woocommerce-product-options-adv' ); ?></a>
	</p>

	<div class="woocommerce_product_options wc-metaboxes">

		<?php
			$pr = new WC_Product_Variable($post->ID);
			$variations = array();
			if ( $pr->is_type( 'variable' ) ) {
				$variables = $pr->get_available_variations();
				foreach($variables as $variable){
					$variation_id = $variable['variation_id'];
					$variation_price = $variable['display_price'];
					$variation_title = current($variable['attributes']);
					
					$variations[] = array(
									'variation_id' => $variation_id,
									'variation_price' => $variation_price,
									'variation_title' => $variation_title,
									);
				}
			}
			
			
			$loop = 0;
			$parentOptions = array();
			$parentOptionValues = array();
			foreach ( $product_options as $k=>$option ) {
				if($option['type']=='select' || $option['type']=='variant'){
					$parentOptions[$k] = $option['name'];
					foreach ( $option['options'] as $opt ){
						$parentOptionValues[$k][] = $opt['label'];
					}
				}
			}
			//echo '<pre>';print_r($parentOptions);echo '</pre>';
			foreach ( $product_options as $option ) {
				include( 'html-option.php' );

				$loop++;
			}
		?>

	</div>

	<div class="toolbar">
		<button type="button" class="button add_new_option button-primary"><?php _e( 'Add New Option', 'woocommerce-product-options-adv' ); ?></button>

		<button type="button" class="button import_options"  style="display:none;"><?php _e( 'Import', 'woocommerce-product-options-adv' ); ?></button>
		<button type="button" class="button export_options"  style="display:none;"><?php _e( 'Export', 'woocommerce-product-options-adv' ); ?></button>

		<textarea name="export_product_option" class="export" cols="20" rows="5" readonly="readonly"><?php echo esc_textarea( serialize( $product_options ) ); ?></textarea>

		<textarea name="import_product_option" class="import" cols="20" rows="5" placeholder="<?php _e('Paste exported form data here and then save to import fields. The imported fields will be appended.', 'woocommerce-product-options-adv'); ?>"></textarea>

	</div>
	<?php if( isset($post->ID) ):?>
    <div class="options_group" style="display:none;">
		<p class="form-field">
        <label for="_product_options_exclude_global"><?php _e( 'Global Option Exclusion', 'woocommerce-product-options-adv' ); ?></label>
        <input id="_product_options_exclude_global" name="_product_options_exclude_global" class="checkbox" type="checkbox" value="1" <?php checked( get_post_meta( $post->ID, '_product_options_exclude_global', TRUE ), 1 ); ?>/><span class="description"><?php _e( 'Check this to exclude this product from all Global Options', 'woocommerce-product-options-adv' ); ?></span>
		</p>
	</div>
	<?php endif; ?>
</div>
<script type="text/javascript">
	jQuery(function(){

		<?php if ( version_compare( WC_VERSION, '2.3.0', '<' ) ) { ?>
			jQuery( 'select.chosen_select' ).chosen();
		<?php } ?>

		jQuery('#product_options_data')
		.on( 'change', '.option_name input', function() {
			if ( jQuery(this).val() )
				jQuery(this).closest('.woocommerce_product_option').find('span.group_name').text( '"' + jQuery(this).val() + '"' );
			else
				jQuery(this).closest('.woocommerce_product_option').find('span.group_name').text('');
		})
		.on( 'change', 'select.product_option_type', function() {

			var value = jQuery(this).val();

			if ( value == 'custom' || value == 'custom_price' || value == 'custom_textarea' || value == 'input_multiplier' || value == 'custom_letters_only' || value == 'custom_digits_only' || value == 'custom_letters_or_digits' ) {
				jQuery(this).closest('.woocommerce_product_option').find('td.minmax_column, th.minmax_column').show();
			} else {
				jQuery(this).closest('.woocommerce_product_option').find('td.minmax_column, th.minmax_column').hide();
			}

			if ( value == 'custom_price' ) {
				jQuery(this).closest('.woocommerce_product_option').find('td.price_column, th.price_column').hide();
			} else {
				jQuery(this).closest('.woocommerce_product_option').find('td.price_column, th.price_column').show();
			}

			// Count the number of options.  If one (or less), disable the remove option buttons
			var removeAddOnOptionButtons = jQuery(this).closest('.woocommerce_product_option').find('button.remove_option_option');
			if ( 2 > removeAddOnOptionButtons.length ) {
				removeAddOnOptionButtons.attr('disabled', 'disabled');
			} else {
				removeAddOnOptionButtons.removeAttr('disabled');
			}
			
			//Variant
			if(value == 'variant'){
				jQuery(this).closest('.woocommerce_product_option').find('.pr_variants').show();
				jQuery(this).closest('.woocommerce_product_option').find('.variant_label').hide();
				jQuery(this).closest('.woocommerce_product_option').find('.price_column').hide();
			}
			else{
				jQuery(this).closest('.woocommerce_product_option').find('.pr_variants').hide();
				jQuery(this).closest('.woocommerce_product_option').find('.variant_label').show();
				jQuery(this).closest('.woocommerce_product_option').find('.price_column').show();
			}
		})
		.on( 'click', '.pr_variants', function() {
			var variant = jQuery(this).val();
			var variant_id = jQuery('option:selected',this).attr('data-variation-id');
			var variant_price = jQuery('option:selected',this).attr('data-variation-price');
			
			jQuery(this).parent().find('.variant_label').val(variant);
			jQuery(this).parent().parent().find('input.variant_id').val(variant_id);
		})
		.on( 'click', 'button.add_option_option', function() {

			var loop = jQuery(this).closest('.woocommerce_product_option').index('.woocommerce_product_option');
			var ok = jQuery(this).closest('.woocommerce_product_option').find('.parent_value').length - 1;

			var html = '<?php
				ob_start();
				$opt['label'] 			= '';
				$opt['parent']			= '';
				$opt['price_prefix'] 	= '';
				$opt['price'] 			= '';
				$opt['weight_prefix']	= '';
				$opt['weight'] 			= '';
				$opt['min'] 			= '';
				$opt['max'] 			= '';
				$option = Product_Option_Admin::get_new_option_option();
				$loop = "{loop}";
				$ok = "{ok}";

				include( 'html-option-option.php' );

				$html = ob_get_clean();
				echo str_replace( array( "\n", "\r" ), '', str_replace( "'", '"', $html ) );
			?>';

			html = html.replace( /{loop}/g, loop );
			html = html.replace( /{ok}/g, ok );

			jQuery(this).closest('.woocommerce_product_option .data').find('tbody').append( html );

			jQuery('select.product_option_type').change();
			
			jQuery('.option_parent select').change();

			return false;
		})
		.on( 'click', '.add_new_option', function() {

			var loop = jQuery('.woocommerce_product_options .woocommerce_product_option').size();

			var html = '<?php
				ob_start();

				$option['name'] 			= '';
				$option['description']		= '';
				$option['required'] 		= '';
				$option['type'] 			= 'checkbox';
				$option['options'] 		= array(
					Product_Option_Admin::get_new_option_option()
				);
				$loop = "{loop}";

				include( 'html-option.php' );

				$html = ob_get_clean();
				echo str_replace( array( "\n", "\r" ), '', str_replace( "'", '"', $html ) );
			?>';

			html = html.replace( /{loop}/g, loop );

			jQuery('.woocommerce_product_options').append( html );

			jQuery('select.product_option_type').change();
			
			updateParentOption();

			return false;
		})
		.on('change', '.option_parent select', function(){
			var selectedParent = jQuery(this).val();
			//var selParentID = jQuery(this).attr('id').replace('option_parent_','');
			var selParentID = jQuery(this).closest('.woocommerce_product_option').index();
			if(selectedParent!='-1'){
				if(selParentID==selectedParent){
					jQuery(this).val('-1');
					alert('You can\'t select this value as parent!');
				}
				else{
					var parentValues = '';
					if(jQuery('[name="product_option_option_label['+selectedParent+'][]"]').length){
						jQuery('[name="product_option_option_label['+selectedParent+'][]"]').each(function(){
							var optValue = jQuery(this).val();
							parentValues += '<option value="'+optValue+'">'+optValue+'</option>';
						});
					}
					jQuery('[name^="product_option_option_parent['+selParentID+']"]').each(function(i,j){
						var prevSelValue = jQuery(this).val();
						jQuery(this).html(parentValues);
						jQuery(this).val(prevSelValue);
					});
				}
			}
			else{
				jQuery('[name^="product_option_option_parent['+selParentID+']"]').each(function(i,j){
						jQuery(this).html('');
				});
			}
		})
		.on( 'click', '.remove_option', function() {

			var answer = confirm('<?php _e('Are you sure you want remove this option?', 'woocommerce-product-options-adv'); ?>');

			if (answer) {
				var option = jQuery(this).closest('.woocommerce_product_option');
				jQuery(option).find('input').val('');
				jQuery(option).hide();
			}

			return false;
		})
		.find('select.product_option_type').change();

		// Import / Export
		jQuery('#product_options_data').on('click', '.export_options', function() {

			jQuery('#product_options_data textarea.import').hide();
			jQuery('#product_options_data textarea.export').slideToggle('500', function() {
				jQuery(this).select();
			});

			return false;
		});

		jQuery('#product_options_data').on('click', '.import_options', function() {

			jQuery('#product_options_data textarea.export').hide();
			jQuery('#product_options_data textarea.import').slideToggle('500', function() {
				jQuery(this).val('');
			});

			return false;
		});

		// Sortable
		jQuery('.woocommerce_product_options').sortable({
			items:'.woocommerce_product_option',
			cursor:'move',
			axis:'y',
			handle:'h3',
			scrollSensitivity:40,
			helper:function(e,ui){
				return ui;
			},
			start:function(event,ui){
				ui.item.css('border-style','dashed');
			},
			stop:function(event,ui){
				ui.item.removeAttr('style');
				option_row_indexes();
				updateParentOption();
				//update_parent_indexes();
			}
		});

		function option_row_indexes() {
			jQuery('.woocommerce_product_options .woocommerce_product_option').each(function(index, el){ jQuery('.product_option_position', el).val( parseInt( jQuery(el).index('.woocommerce_product_options .woocommerce_product_option') ) ); });
		};

		// Sortable options
		jQuery('.woocommerce_product_option .data table tbody').sortable({
			items:'tr',
			cursor:'move',
			axis:'y',
			scrollSensitivity:40,
			helper:function(e,ui){
				ui.children().each(function(){
					jQuery(this).width(jQuery(this).width());
				});
				return ui;
			},
			start:function(event,ui){
				ui.item.css('background-color','#f6f6f6');
			},
			stop:function(event,ui){
				ui.item.removeAttr('style');
			}
		});

		// Remove option
// 		jQuery('button.remove_option_option').live('click', function(){
		jQuery('button.remove_option_option').on('click', function(){

			var answer = confirm('<?php _e('Are you sure you want delete this option?', 'woocommerce-product-options-adv'); ?>');

			if (answer) {
				var addOn = jQuery(this).closest('.woocommerce_product_option');
				jQuery(this).closest('tr').remove();
				addOn.find('select.product_option_type').change();
			}

			return false;

		});
		
		function updateParentOption(){
			var parentOptions = [];
			var parentOptionsName = [];
			jQuery('.woocommerce_product_option.wc-metabox').each(function(){
				var selOptType = jQuery(this).find('.product_option_type').val();
				
				if(selOptType=='select' || selOptType=='variant'){
					var selOptName = jQuery(this).find('.option_name > input').attr('id');
					selOptName = selOptName.replace('option_name_','');
					var selOptValue = jQuery(this).find('.option_name > input').val();
					parentOptions.push(selOptValue);
					parentOptionsName.push(selOptName);
				}
			});
			if(parentOptions.length > 0){
				var parent_option = '';
				jQuery.each(parentOptions, function(i,j){
					//parentOptionsName[i];
					parent_option += '<option value="'+i+'">'+j+'</option>';
				});
				jQuery('.woocommerce_product_option .option_parent select').each(function(){
					//var prevValue = jQuery(this).val();
					var prevText = jQuery('option:selected',this).text();
					var prevValue = parentOptions.indexOf(prevText);
					
					jQuery(this).find('.parent_options').html(parent_option);
					jQuery(this).val(prevValue);
				});
			}
		}
		
		function update_parent_indexes(){
			jQuery('.woocommerce_product_options .woocommerce_product_option').each(function(index, el){
			});
		}

	});
</script>
