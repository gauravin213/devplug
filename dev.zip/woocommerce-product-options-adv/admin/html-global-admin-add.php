<div class="wrap woocommerce">
	<div class="icon32 icon32-posts-product" id="icon-woocommerce"><br/></div>

    <h2><?php _e( 'Add/Edit Global Option', 'woocommerce-product-options-adv' ) ?></h2><br/>

	<form method="POST" action="">
		<table class="form-table global-options-form meta-box-sortables">
			<tr>
				<th>
					<label for="option-reference"><?php _e( 'Global Option Reference', 'woocommerce-product-options-adv' ); ?></label>
				</th>
				<td>
					<input type="text" name="option-reference" id="option-reference" style="width:50%;" value="<?php echo esc_attr( $reference ); ?>" />
					<p class="description"><?php _e( 'Give this global add-on a reference/name to make it recognisable.', 'woocommerce-product-options-adv' ); ?></p>
				</td>
			</tr>
			<tr>
				<th>
					<label for="option-priority"><?php _e( 'Priority', 'woocommerce-product-options-adv' ); ?></label>
				</th>
				<td>
					<input type="text" name="option-priority" id="option-priority" style="width:50%;" value="<?php echo esc_attr( $priority ); ?>" />
					<p class="description"><?php _e( 'Give this global option a priority - this will deternmine the order in which multiple groups of options get displayed on the frontend. Per-product add-ons will always have priority 10.', 'woocommerce-product-options-adv' ); ?></p>
				</td>
			</tr>
			<tr>
				<th>
					<label for="option-objects"><?php _e( 'Applied to...', 'woocommerce-product-options-adv' ); ?></label>
				</th>
				<td>
					<select id="option-objects" name="option-objects[]" multiple="multiple" style="width:50%;" data-placeholder="<?php _e('Choose some options&hellip;', 'woocommerce-product-options-adv'); ?>" class="chosen_select wc-enhanced-select">
						<option value="0" <?php selected( in_array( '0', $objects ), true ); ?>><?php _e( 'All Products', 'woocommerce-product-options-adv' ); ?></option>
						<optgroup label="<?php _e( 'Product category notifications', 'woocommerce-product-options-adv' ); ?>">
							<?php
								$terms = get_terms( 'product_cat', array( 'hide_empty' => 0 ) );

								foreach ( $terms as $term ) {
									echo '<option value="' . $term->term_id . '" ' . selected( in_array( $term->term_id, $objects ), true, false ) . '>' . __( 'Category:', 'woocommerce-product-options-adv' ) . ' ' . $term->name . '</option>';
								}
							?>
						</optgroup>
						<?php do_action( 'woocommerce_product_options_global_edit_objects', $objects ); ?>
					</select>
					<p class="description"><?php _e( 'Choose categories which should show these options (or apply to all products).', 'woocommerce-product-options-adv' ); ?></p>
				</td>
			</tr>
			<tr>
				<th>
					<label for="option-objects"><?php _e( 'Options', 'woocommerce-product-options-adv' ); ?></label>
				</th>
				<td id="poststuff" class="postbox">
					<?php include( 'html-option-panel.php' ); ?>
				</td>
			</tr>
		</table>
		<p class="submit">
			<input type="hidden" name="edit_id" value="<?php if ( ! empty( $edit_id ) ) echo $edit_id; ?>" />
			<input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e( 'Save Global Option', 'woocommerce-product-options-adv' ); ?>">
		</p>
	</form>
</div>
<script type="text/javascript">
	// Toggle function
	function openclose() {
		jQuery('.wc-metabox').toggleClass( 'closed' ).toggleClass( 'open' );
	}
	// Open and close the Product Add-On metaboxes
	jQuery('.wc-metaboxes-wrapper').on('click', '.wc-metabox h3', function(event){
		// If the user clicks on some form input inside the h3, like a select list (for variations), the box should not be toggled
		if (jQuery(event.target).filter(':input, option').length) return;

		jQuery(this).next('.wc-metabox-content').toggle();
		openclose();
		})
	.on('click', '.expand_all', function(){
		jQuery(this).closest('.wc-metaboxes-wrapper').find('.wc-metabox > table').show();
		openclose();
		return false;
	})
	.on('click', '.close_all', function(){
		jQuery(this).closest('.wc-metaboxes-wrapper').find('.wc-metabox > table').hide();
		openclose();
		return false;
	});
	jQuery('.wc-metabox.closed').each(function(){
		jQuery(this).find('.wc-metabox-content').hide();
	});
</script>
